package com.eye.allseeingirc;

import java.util.ArrayList;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v13.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.eye.allseeingirc.adapter.KeywordListAdapter;
import com.eye.allseeingirc.adapter.NotiLogListAdapter;
import com.eye.allseeingirc.adapter.QueryListAdapter;
import com.eye.allseeingirc.adapter.TalkListAdapter;
import com.eye.allseeingirc.bean.KeywordBean;
import com.eye.allseeingirc.bean.NotificationBean;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.listener.AuthDelButtonClick;
import com.eye.allseeingirc.listener.ChatItemClick;
import com.eye.allseeingirc.listener.ChatItemLongClick;
import com.eye.allseeingirc.listener.DelAllKeywordButtonClick;
import com.eye.allseeingirc.listener.DelDataButtonClick;
import com.eye.allseeingirc.listener.KeywordAddClick;
import com.eye.allseeingirc.listener.KeywordItemLongClick;
import com.eye.allseeingirc.listener.NotiDelClick;
import com.eye.allseeingirc.listener.NotiItemClick;
import com.eye.allseeingirc.listener.QueryItemClick;
import com.eye.allseeingirc.listener.QueryItemLongClick;
import com.eye.allseeingirc.listener.UserNicknameClick;
import com.eye.allseeingirc.view.ListViewUtils;

public class MainActivity extends Activity implements ActionBar.TabListener {
	private final static int REQ_CODE_GALLERY = 100;

	AllSeiingIRCApplication application;

	ActionBar actionBar;
	SectionsPagerAdapter mSectionsPagerAdapter;
	ViewPager mViewPager;
	int[] tabIcon = { R.drawable.custom_tab1, R.drawable.custom_tab2,
			R.drawable.custom_tab3, R.drawable.custom_tab4 };
	static TabUtil[] tabUtil = new TabUtil[4];
	Drawable[] homeIcon = new Drawable[2];

	MenuItem itemAdd;

	static ArrayList<TalkListBean> list = new ArrayList<TalkListBean>();
	static TalkListAdapter adapter;

	static ArrayList<TalkListBean> queryList = new ArrayList<TalkListBean>();
	static QueryListAdapter queryAdapter;

	static ArrayList<NotificationBean> notiList = new ArrayList<NotificationBean>();
	static ArrayList<NotificationBean> allNotiList = new ArrayList<NotificationBean>();
	static NotiLogListAdapter notiAdapter;

	static ArrayList<KeywordBean> keywordList = new ArrayList<KeywordBean>();
	static KeywordListAdapter keywordAdapter;

	static TextView tvMyNick;

	private Dialog addChanDialog;

	static boolean isRemoteOn = false;
	boolean isAddChan = true;
	static boolean firstDragFlag = true;
	static boolean lockListView;

	MyChannelDatabase myChannelDatabase;
	MyQueryDatabase myQueryDatabase;
	static NotiLogDatabase notiLogDB;
	static ListView lvKeyword;
	KeywordDatabase keywordDB;
	static int notiCnt = 0;
	static int chanCnt = 0;
	static int queryCnt = 0;

	static public int currPageIdx = 0;

	static ImageView ivBackcustom;
	static ImageView ivBackcurr;
	static boolean back = true;
	static int backRes = 0;
	static String backUri = "";

	static ArrayList<RadioButton> notiOptions = new ArrayList<RadioButton>();
	static int checkedRadio=0;
	
	public static int currPosition=0;
	public static int max=10;
	
	static Button btCancel;
	
	public static int[] radioToType={0,0,5,4,2,7,3,6,1};
	
	public static boolean processKillFlag;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		homeIcon[0] = getResources().getDrawable(R.drawable.remote_off);
		homeIcon[1] = getResources().getDrawable(R.drawable.remote_on);
		processKillFlag=true;
		SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);

		application = (AllSeiingIRCApplication) getApplication();
		myChannelDatabase = new MyChannelDatabase(this);
		myQueryDatabase = new MyQueryDatabase(this);
		notiLogDB = new NotiLogDatabase(this);
		keywordDB = new KeywordDatabase(this);

		if (application.remoteClientNetwork == null) {
			application.setRemoteClient(pref.getString("ip", ""), mainHandler,
					null);
		} else {
			application.setNetworkHandler(mainHandler, null);
		}

		actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
		actionBar.setHomeButtonEnabled(true);
		actionBar.setIcon(homeIcon[0]);

		mSectionsPagerAdapter = new SectionsPagerAdapter(getFragmentManager());

		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);

		mViewPager
				.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						actionBar.setSelectedNavigationItem(position);
					}
				});

		for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
			tabUtil[i] = new TabUtil();
			actionBar.addTab(actionBar
					.newTab()
					.setTabListener(this)
					.setCustomView(
							tabUtil[i].renderTabView(MainActivity.this,
									tabIcon[i], 0)));
		}

		adapter = new TalkListAdapter(this, list);
		queryAdapter = new QueryListAdapter(this, queryList);
		notiAdapter = new NotiLogListAdapter(this, notiList);
		keywordAdapter = new KeywordListAdapter(this, keywordList);

		Intent temp = getIntent();
		int noti = temp.getIntExtra("noti", 0);
		if (noti == 1) {// ä��
			Intent nextActivity = new Intent(this, ChatActivity.class);
			nextActivity.putExtra("listItem", temp.getStringExtra("name"));
			startActivity(nextActivity);
		} else if (noti == 2) {// �ϴ���
			Intent nextActivity = new Intent(this, QueryActivity.class);
			MyQueryDatabase db = new MyQueryDatabase(this);
			int queryId = db.getQueryId(temp.getStringExtra("name"));
			nextActivity.putExtra("listItem", temp.getStringExtra("name"));
			nextActivity.putExtra("queryId", queryId);
			startActivity(nextActivity);
		}

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		application.stopRemoteClient();
		if(processKillFlag){
			android.os.Process.killProcess(android.os.Process.myPid());
		}
		Log.e("activity", "destroy");

	}

	@Override
	protected void onResume() {
		super.onResume();
		application.setNetworkHandler(mainHandler, null);
		if (application.remoteClientNetwork.socket.isConnected()) {
			actionBar.setIcon(homeIcon[1]);
			isRemoteOn = true;
		} else {
			actionBar.setIcon(homeIcon[0]);
			isRemoteOn = false;
		}
		chanCnt = myChannelDatabase.setTalkList(list);
		queryCnt = myQueryDatabase.setTalkList(queryList);
		tabUtil[0].updateTabBadge(chanCnt);
		tabUtil[1].updateTabBadge(queryCnt);
		adapter.notifyDataSetChanged();
		queryAdapter.notifyDataSetChanged();
		//((RadioButton)notiOptions.get(0)).setChecked(true);
		notiCnt = notiLogDB.setNotiLog(allNotiList);
		notiList.clear();
		if (currPageIdx == 2) {
			max = 10;
			if (max > allNotiList.size()) {
				max = allNotiList.size();
			}
			int i=0;
			for (; i < max; i++) {
				notiList.add(allNotiList.get(i));
				//allNotiList.remove(0);
			}
			currPosition=i;
			notiCnt = 0;
		}
		tabUtil[2].updateTabBadge(notiCnt);
		notiAdapter.notifyDataSetChanged();
		keywordDB.setKeywordList(keywordList);

	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		itemAdd = menu.findItem(R.id.action_add);
		itemAdd.setVisible(true);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();

		switch (id) {

		case R.id.action_add:
			if (isAddChan) {
				addChanDialog = createDialog();
				addChanDialog.show();
			} else {
				addChanDialog = createQueryDialog();
				addChanDialog.show();
			}
			break;

		case android.R.id.home:
			if (isRemoteOn) {
				application.stopRemoteClient();
			} else {
				SharedPreferences pref = getSharedPreferences("pref",
						MODE_PRIVATE);
				application.setRemoteClient(pref.getString("ip", ""),
						mainHandler, null);
			}
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private AlertDialog createDialog() {
		final View innerView = getLayoutInflater().inflate(
				R.layout.dialog_addchan, null);
		AlertDialog.Builder ab = new AlertDialog.Builder(this);
		ab.setTitle("ä�� �߰�");
		ab.setView(innerView);

		final EditText chanName = (EditText) innerView
				.findViewById(R.id.edit_chanName);
		final EditText chanPassword = (EditText) innerView
				.findViewById(R.id.edit_chanPassword);

		ab.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (!chanName.getText().toString().trim().equals("")) {
					String password;
					if ("".equals(chanPassword.getText().toString())) {
						password = "";
					} else {
						password = " " + chanPassword.getText().toString();
					}
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/join "
								+ chanName.getText().toString() + password);
						application.remoteClientNetwork.sendMessage(jsonObject
								.toString());
					} catch (JSONException e) {
						e.printStackTrace();
					}
				} else {
					Toast.makeText(MainActivity.this, "ä�θ��� ����ֽ��ϴ�.",
							Toast.LENGTH_SHORT).show();
				}
			}
		});

		ab.setNegativeButton("���", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				setDismiss(addChanDialog);
			}
		});

		return ab.create();
	}

	private AlertDialog createQueryDialog() {
		final View innerView = getLayoutInflater().inflate(
				R.layout.dialog_addquery, null);
		AlertDialog.Builder ab = new AlertDialog.Builder(this);
		ab.setTitle("��ȭ �߰�");
		ab.setView(innerView);

		final EditText nickName = (EditText) innerView
				.findViewById(R.id.edit_queryName);

		ab.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent queryIntent=new Intent(MainActivity.this,QueryActivity.class);
				MyQueryDatabase db=new MyQueryDatabase(MainActivity.this);
				int queryId=db.getQueryId(nickName.getText().toString());
				queryIntent.putExtra("queryId", queryId);
				queryIntent.putExtra("listItem", nickName.getText().toString());
				startActivity(queryIntent); 
			}
		});

		ab.setNegativeButton("���", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				setDismiss(addChanDialog);
			}
		});

		return ab.create();
	}

	private void setDismiss(Dialog dialog) {
		if (dialog != null && dialog.isShowing())
			dialog.dismiss();
	}

	@Override
	public void onTabSelected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
		mViewPager.setCurrentItem(tab.getPosition());
		actionBar
				.setTitle(mSectionsPagerAdapter.getPageTitle(tab.getPosition()));
		currPageIdx = tab.getPosition();
		Log.e("currPageIdx", currPageIdx + "");
		switch (tab.getPosition()) {
		case 0:
			if (itemAdd != null)
				itemAdd.setVisible(true);
			isAddChan = true;
			break;
		case 1:
			if (itemAdd != null)
				itemAdd.setVisible(true);
			isAddChan = false;
			break;
		case 2:
			if (itemAdd != null)
				itemAdd.setVisible(false);
			notiLogDB.setNotiLog(allNotiList);
			notiList.clear();

			int j;
			for(j=0;j<8;j++){
				if(((RadioButton)notiOptions.get(j)).isChecked()){
					checkedRadio=j+1;
					j=9;
				}
			}
			if(j==8){
				((RadioButton)notiOptions.get(0)).setChecked(true);
			}else if(j==10){
				if(checkedRadio==1){
					max = 10;
					if (max > allNotiList.size()) {
						max = allNotiList.size();
					}
					int i=0;
					for (; i < max; i++) {
						notiList.add(allNotiList.get(i));
						//allNotiList.remove(0);
					}
					currPosition=i;
					notiAdapter.notifyDataSetChanged();
				}else{
					((RadioButton)notiOptions.get(0)).setChecked(true);
				}
			}

			notiCnt = 0;
			
			tabUtil[2].updateTabBadge(notiCnt);
			notiLogDB.setAllNotiRead();
			break;

		default:
			backRes = 0;
			backUri = "";
			if (itemAdd != null)
				itemAdd.setVisible(false);
			ivBackcustom.setImageBitmap(null);
			
			break;
		}

	}

	@Override
	public void onTabUnselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	@Override
	public void onTabReselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			return PlaceholderFragment.newInstance(position + 1);
		}

		@Override
		public int getCount() {
			return 4;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.title_section1).toUpperCase(l);
			case 1:
				return getString(R.string.title_section2).toUpperCase(l);
			case 2:
				return getString(R.string.title_section3).toUpperCase(l);
			case 3:
				return getString(R.string.title_section4).toUpperCase(l);
			}
			return null;
		}
	}

	public static class PlaceholderFragment extends Fragment {
		private static final String ARG_SECTION_NUMBER = "section_number";

		
		ListView notiListView;

		public static PlaceholderFragment newInstance(int sectionNumber) {
			PlaceholderFragment fragment = new PlaceholderFragment();
			Bundle args = new Bundle();
			args.putInt(ARG_SECTION_NUMBER, sectionNumber);
			fragment.setArguments(args);
			return fragment;
		}

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {

			Bundle args = this.getArguments();

			switch (args.getInt(ARG_SECTION_NUMBER)) {
			// // ä�� ��
			case 1:
				View myChanView = inflater.inflate(R.layout.fragment_talklist,
						container, false);
				ListView listView = (ListView) myChanView
						.findViewById(R.id.listView_talk);
				listView.setEmptyView(myChanView.findViewById(R.id.empty_talk));

				listView.setAdapter(adapter);

				// ��ȭ��� ����Ʈ�� ������ �޾���
				listView.setOnItemClickListener(new ChatItemClick(
						getActivity(), list));
				listView.setOnItemLongClickListener(new ChatItemLongClick(
						getActivity(), adapter, list, handler));

				return myChanView;

				// ��ȭ ��
			case 2:
				View myTalkView = inflater.inflate(R.layout.fragment_query,
						container, false);
				ListView queryListView = (ListView) myTalkView
						.findViewById(R.id.listView_query);
				queryListView.setEmptyView(myTalkView
						.findViewById(R.id.empty_query));

				queryListView.setAdapter(queryAdapter);

				// ������ �ٴ� �κ�
				queryListView.setOnItemClickListener(new QueryItemClick(
						getActivity(), queryList));
				queryListView
						.setOnItemLongClickListener(new QueryItemLongClick(
								getActivity(), queryAdapter, queryList, handler));

				return myTalkView;

				// �˸� ��
			case 3:
				View notificationView;
				notificationView = inflater.inflate(
						R.layout.fragment_notification, container, false);
				checkedRadio=0;
				notiListView = (ListView) notificationView
						.findViewById(R.id.listView_noti);
				notiListView.setEmptyView(notificationView
						.findViewById(R.id.empty_noti));
				notiListView.setAdapter(notiAdapter);
				notiListView.setOnTouchListener(new OnTouchListener() {
					boolean dragFlag = false;
					float startYPosition = 0, endYPosition = 0;

					@Override
					public boolean onTouch(View v, MotionEvent event) {
						switch (event.getAction()) {
						case MotionEvent.ACTION_UP:

							endYPosition = event.getY();
							if ((startYPosition > endYPosition)
									&& (startYPosition - endYPosition) > 300
									&& dragFlag && lockListView == false&&checkedRadio==1) {
								addItems();
							}
							dragFlag = false;
							startYPosition = 0.0f;
							endYPosition = 0.0f;
							firstDragFlag = true;
							break;

						case MotionEvent.ACTION_MOVE:
							break;

						case MotionEvent.ACTION_DOWN:
							if (firstDragFlag
									&& notiListView.getLastVisiblePosition() == notiList
											.size() - 1) {
								startYPosition = event.getY(); // ù��° ��ġ�� Y(����)��
																// ����
								dragFlag = true;

								firstDragFlag = false;
							}

							break;

						default:
							break;
						}
						return false;
					}
				});

				notiOptions.clear();
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option1));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option2));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option3));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option4));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option5));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option6));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option7));
					notiOptions.add((RadioButton) notificationView
							.findViewById(R.id.option8));
					for (RadioButton button : notiOptions) {
						button.setOnCheckedChangeListener(new OnCheckedChangeListener() {
							public void onCheckedChanged(
									CompoundButton buttonView, boolean isChecked) {
								if (isChecked)
									processRadioButtonClick(buttonView);
							}
						});
					}
				

				Button btnDelete = (Button) notificationView
						.findViewById(R.id.button_del_alllog);
				btnDelete.setOnClickListener(new NotiDelClick(getActivity(),
						notiList,allNotiList, notiAdapter));

				notiListView.setOnItemClickListener(new NotiItemClick(
						getActivity(), notiList));
				return notificationView;

			default:
				View settingView;
				settingView = inflater.inflate(R.layout.fragment_setting,
						container, false);
				SharedPreferences pref = getActivity().getSharedPreferences(
						"pref", MODE_PRIVATE);

				tvMyNick = (TextView) settingView.findViewById(R.id.tv_mynick);
				tvMyNick.setText(pref.getString("mynick", ""));
				Button btnMyNick = (Button) settingView
						.findViewById(R.id.bt_mynick_submit);
				btnMyNick.setOnClickListener(new UserNicknameClick(
						getActivity()));
				
				// Ű���� edit text
				final EditText etKeyword = (EditText) settingView
						.findViewById(R.id.et_keyword);
				// Ű���� buttons
				Button addKey = (Button) settingView
						.findViewById(R.id.bt_submit_keyword);
				//Button delKey = (Button) settingView.findViewById(R.id.bt_del_keyword);
				// Ű���� ����Ʈ�� ����

				lvKeyword = (ListView) settingView
						.findViewById(R.id.lv_keyword_list);
				lvKeyword.setEmptyView(settingView
						.findViewById(R.id.tv_empty_list));
				lvKeyword.setAdapter(keywordAdapter);

				keywordAdapter.notifyDataSetChanged();
				ListViewUtils.listViewHeightSet(keywordAdapter, lvKeyword);
				lvKeyword.setOnItemLongClickListener(new KeywordItemLongClick(getActivity(), keywordList));

				// Ű���� ��ư ������ ���
				addKey.setOnClickListener(new KeywordAddClick(getActivity(), etKeyword));
				//delKey.setOnClickListener(new KeywordDelClick(getActivity(), keywordList));

				ImageView ivBack1 = (ImageView) settingView
						.findViewById(R.id.iv_back_1);
				ImageView ivBack2 = (ImageView) settingView
						.findViewById(R.id.iv_back_2);
				ImageView ivBack3 = (ImageView) settingView
						.findViewById(R.id.iv_back_3);
				ImageView ivBack4 = (ImageView) settingView
						.findViewById(R.id.iv_back_4);
				ImageView ivBack5 = (ImageView) settingView
						.findViewById(R.id.iv_back_5);
				ImageView ivBack6 = (ImageView) settingView
						.findViewById(R.id.iv_back_6);
				ImageView ivBack7 = (ImageView) settingView
						.findViewById(R.id.iv_back_7);
				TextView tvAlbum = (TextView) settingView
						.findViewById(R.id.tv_album);
				ivBackcurr = (ImageView) settingView
						.findViewById(R.id.iv_back_curr);
				ivBackcustom = (ImageView) settingView
						.findViewById(R.id.iv_back_custom);
				// ��� ���� ��ư
				Button backSubmit = (Button) settingView
						.findViewById(R.id.bt_back_submit);

				final SharedPreferences.Editor editor = pref.edit();

				if (pref.getBoolean("back", false)) {
					int backres = pref.getInt("backres",
							R.drawable.background_5);
					ivBackcurr.setImageResource(backres);
				} else {
					String uri = pref.getString("backuri", "");
					if (uri.equals("")) {
						ivBackcurr.setImageResource(R.drawable.background_5);
					} else {

						ivBackcurr.setImageURI(Uri.parse(uri));
					}
				}

				// ��ư ������
				ivBack1.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// editor.putBoolean("back", true);
						// editor.putInt("backres", R.drawable.background_1);
						// editor.commit();
						back = true;
						backRes = R.drawable.background_1;

						ivBackcustom.setImageResource(R.drawable.background_1);
					}
				});
				ivBack2.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_2;
						ivBackcustom.setImageResource(R.drawable.background_2);
					}
				});
				ivBack3.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_3;
						ivBackcustom.setImageResource(R.drawable.background_3);
					}
				});
				ivBack4.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_4;
						ivBackcustom.setImageResource(R.drawable.background_4);
					}
				});
				ivBack5.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_5;
						ivBackcustom.setImageResource(R.drawable.background_5);
					}
				});
				ivBack6.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_6;
						ivBackcustom.setImageResource(R.drawable.background_6);
					}
				});
				ivBack7.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						back = true;
						backRes = R.drawable.background_7;
						ivBackcustom.setImageResource(R.drawable.background_7);
					}
				});
				tvAlbum.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent i = new Intent(Intent.ACTION_GET_CONTENT);
						i.setType("image/*");
						i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						getActivity().startActivityForResult(i,
								REQ_CODE_GALLERY);
					}
				});
				backSubmit.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {

						if (back) {
							if (backRes == 0) {
								Toast.makeText(getActivity(),
										"����� ���õ��� �ʾҽ��ϴ�.", Toast.LENGTH_SHORT)
										.show();
							} else {
								editor.putBoolean("back", back);
								editor.putInt("backres", backRes);
								editor.commit();
								ivBackcurr.setImageResource(backRes);
								backRes = 0;
								Toast.makeText(getActivity(), "����� ����Ǿ����ϴ�.",
										Toast.LENGTH_SHORT).show();
								ivBackcustom.setImageBitmap(null);
							}
						} else {
							if (backUri.equals("")) {
								Toast.makeText(getActivity(),
										"����� ���õ��� �ʾҽ��ϴ�.", Toast.LENGTH_SHORT)
										.show();
							} else {
								editor.putBoolean("back", back);
								editor.putString("backuri", backUri);
								editor.commit();
								ivBackcurr.setImageURI(Uri.parse(backUri));
								backUri = "";
								Toast.makeText(getActivity(), "����� ����Ǿ����ϴ�.",
										Toast.LENGTH_SHORT).show();
								ivBackcustom.setImageBitmap(null);
							}
						}
					}
				});
				
				TextView tvMyIp=(TextView)settingView.findViewById(R.id.tv_myIp);
				tvMyIp.setText(pref.getString("ip", ""));

				btCancel = (Button) settingView
						.findViewById(R.id.bt_auth_cancel);
				btCancel.setOnClickListener(new AuthDelButtonClick(
						getActivity(), handler));
				
				Button delData=(Button)settingView.findViewById(R.id.bt_del_data);
				delData.setOnClickListener(new DelDataButtonClick(getActivity(), handler));
					delData.setEnabled(isRemoteOn);
					Button delAllKeyword=(Button)settingView.findViewById(R.id.bt_del_all_keyword);
					delAllKeyword.setOnClickListener(new DelAllKeywordButtonClick(getActivity()));
					

				return settingView;
			}
		}

		private void processRadioButtonClick(CompoundButton buttonView) {
			for (RadioButton button : notiOptions) {
				if (button.isChecked()&&button != buttonView){
						button.setChecked(false);
				}
			}
			switch (buttonView.getId()) {
			case R.id.option1:
				Log.e("click", "1");
				checkedRadio=1;
				notiList.clear();
				max = 10;
				if (max > allNotiList.size()) {
					max = allNotiList.size();
				}
				int i=0;
				for (; i < max; i++) {
					notiList.add(allNotiList.get(i));
					//allNotiList.remove(0);
				}
				currPosition=i;
				notiAdapter.notifyDataSetChanged();
				break;
			case R.id.option2:
				Log.e("click", "2");
				checkedRadio=2;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option3:
				Log.e("click", "3");
				checkedRadio=3;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option4:
				Log.e("click", "4");
				checkedRadio=4;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option5:
				Log.e("click", "5");
				checkedRadio=5;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option6:
				Log.e("click", "6");
				checkedRadio=6;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option7:
				Log.e("click", "7");
				checkedRadio=7;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;
			case R.id.option8:
				Log.e("click", "8");
				checkedRadio=8;
				notiAdapter.filter(radioToType[checkedRadio], allNotiList);
				break;

			default:
				break;
			}
			

		}

		private void addItems() {
			lockListView = true;

			Runnable run = new Runnable() {

				@Override
				public void run() {
					int position = notiList.size() - 1;

					max += 10;
					if (max > allNotiList.size()) {
						max = allNotiList.size();
					}
					int i=currPosition;
					for (; i < max; i++) {
						notiList.add(allNotiList.get(i));
						//allNotiList.remove(0);
					}
					currPosition=i;
					notiAdapter.notifyDataSetChanged();

					if (allNotiList.size() == currPosition) {
						Toast.makeText(getActivity(), "�� �̻� �˸��� �����ϴ�.",
								Toast.LENGTH_SHORT).show();
						notiListView.setSelection(currPosition-1);
					} else {
						notiListView.smoothScrollToPosition(position + 1);
					}

					lockListView = false;
				}
			};

			Handler postHandler = new Handler();
			postHandler.postDelayed(run, 0);

		}

		Handler handler = new Handler() {
			public void handleMessage(Message message) {
				switch (message.what) {
				case 0:
					chanCnt -= message.arg1;
					tabUtil[0].updateTabBadge(chanCnt);
					break;
				case 1:
					processKillFlag=false;
					getActivity().finish();
					break;
				case 2:
					queryCnt -= message.arg1;
					tabUtil[0].updateTabBadge(chanCnt);
					break;
				case 3:
					MyChannelDatabase myChannelDatabase=new MyChannelDatabase(getActivity());
					MyQueryDatabase myQueryDatabase=new MyQueryDatabase(getActivity());
					KeywordDatabase keywordDB=new KeywordDatabase(getActivity());
					chanCnt = myChannelDatabase.setTalkList(list);
					queryCnt = myQueryDatabase.setTalkList(queryList);
					tabUtil[0].updateTabBadge(chanCnt);
					tabUtil[1].updateTabBadge(queryCnt);
					adapter.notifyDataSetChanged();
					queryAdapter.notifyDataSetChanged();
					//((RadioButton)notiOptions.get(0)).setChecked(true);
					notiCnt = notiLogDB.setNotiLog(allNotiList);
					notiList.clear();
					if (currPageIdx == 2) {
						max = 10;
						if (max > allNotiList.size()) {
							max = allNotiList.size();
						}
						int i=0;
						for (; i < max; i++) {
							notiList.add(allNotiList.get(i));
							//allNotiList.remove(0);
						}
						currPosition=i;
						notiCnt = 0;
					}
					tabUtil[2].updateTabBadge(notiCnt);
					notiAdapter.notifyDataSetChanged();
					keywordDB.setKeywordList(keywordList);
					break;
				default:
					break;
				}
			}
		};

	}

	public Handler mainHandler = new Handler() {
		public void handleMessage(Message message) {
			switch (message.what) {
			case 0:

				actionBar.setIcon(homeIcon[1]);
				if (btCancel != null) {
					btCancel.setEnabled(true);
				}
				Log.e("MainActivity", "���� ��");
				break;

			case 1:
				actionBar.setIcon(homeIcon[0]);
				if (btCancel != null) {
					btCancel.setEnabled(false);
				}
				Log.e("MainActivity", "���� �ȵ�");
				isRemoteOn = false;
				break;

			case 2:
				actionBar.setIcon(homeIcon[0]);
				if (btCancel != null) {
					btCancel.setEnabled(false);
				}
				Log.e("MainActivity", "���� �ȵ�");
				isRemoteOn = false;
				break;

			case 5:// �޽��� �޾��� ���� �ڵ鷯
				switch (message.arg1) {
				case 0:// �ο��� ���� : ����
					String chan = message.obj.toString();
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getChanName().equals(chan)) {
							list.get(i).setCount(list.get(i).getCount() + 1);
							adapter.notifyDataSetChanged();
							i = list.size();
						}
					}
					break;
				case 1:// �ο��� ���� : ����
					chan = message.obj.toString();
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getChanName().equals(chan)) {
							list.get(i).setCount(list.get(i).getCount() - 1);
							adapter.notifyDataSetChanged();
							i = list.size();
						}
					}
					break;
				case 2:// ���ο� �޽��� ���� �� ����Ʈ�� ����
					
					chan = ((TalkListBean) message.obj).getChanName();
					if (((TalkListBean) message.obj).isChan) {

							tabUtil[0].updateTabBadge(++chanCnt);

						for (int i = 0; i < list.size(); i++) {
							if (list.get(i).getChanName().equals(chan)) {
								TalkListBean bean = list.get(i);
								bean.setBadge(list.get(i).getBadge() + 1);
								bean.setLatestMsg(((TalkListBean) message.obj)
										.getLatestMsg());
								bean.setLatestTime(((TalkListBean) message.obj)
										.getLatestTime());
								list.remove(i);
								list.add(0, bean);
								adapter.notifyDataSetChanged();
								i = list.size();
							}
						}
					} else {
						tabUtil[1].updateTabBadge(++queryCnt);
						boolean flag = true;
						for (int i = 0; i < queryList.size(); i++) {
							if (queryList.get(i).getChanName().equals(chan)) {
								TalkListBean bean = queryList.get(i);
								bean.setBadge(queryList.get(i).getBadge() + 1);
								bean.setLatestMsg(((TalkListBean) message.obj)
										.getLatestMsg());
								bean.setLatestTime(((TalkListBean) message.obj)
										.getLatestTime());
								queryList.remove(i);
								queryList.add(0, bean);
								queryAdapter.notifyDataSetChanged();
								i = queryList.size();
								flag = false;
							}
						}
						if (flag) {
							TalkListBean bean = (TalkListBean) message.obj;
							bean.setBadge(1);
							queryList.add(0, bean);
							queryAdapter.notifyDataSetChanged();
						}
					}
					break;
				case 3:// �� ����
					chan = ((TalkListBean) message.obj).getChanName();
					int count = ((TalkListBean) message.obj).getCount();
					if (message.arg2 == 0) {
						for (int i = 0; i < list.size(); i++) {
							if (list.get(i).getChanName().equals(chan)) {
								list.get(i).setCount(count);
								list.get(i).setIsSubOn(true);
								adapter.notifyDataSetChanged();
								i = list.size();
							}
						}
					} else if (message.arg2 == 1) {
						TalkListBean bean = new TalkListBean(chan, count);
						list.add(0, bean);
					}
					break;

				case 4:
					chan = message.obj.toString();
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getChanName().equals(chan)) {
							list.get(i).setIsSubOn(false);
							adapter.notifyDataSetChanged();
							i = list.size();
						}
					}
					break;
				case 5:// ä�θ�� ������Ʈ
						// MyChannelDatabase myChannelDatabase = new
						// MyChannelDatabase(MainActivity.this);
					chanCnt = myChannelDatabase.setTalkList(list);
					tabUtil[0].updateTabBadge(chanCnt);
					adapter.notifyDataSetChanged();

					break;
				case 6:// ��ȭ��� ������Ʈ
					queryCnt = myQueryDatabase.setTalkList(queryList);
					tabUtil[1].updateTabBadge(queryCnt);
					queryAdapter.notifyDataSetChanged();
					break;
				case 7:// �����޽���
					Toast.makeText(MainActivity.this, message.obj.toString(),
							Toast.LENGTH_SHORT).show();
					break;
				case 8:// ���к���
					if (tvMyNick != null) {
						String mynick = message.obj.toString();
						tvMyNick.setText(mynick);
					}
					break;

				case 9:// ��Ƽ �α� �ֱ�
					if (currPageIdx == 2) {
						NotiLogDatabase notiDB = new NotiLogDatabase(
								MainActivity.this);
						NotificationBean data=(NotificationBean) message.obj;
						if(checkedRadio==1){
							notiList.add(0,data);
						}else{
							if(radioToType[checkedRadio]==data.getType()){
								notiList.add(0,data);
							}
						}
						currPosition++;
						allNotiList.add(0, (NotificationBean) message.obj);
						notiAdapter.notifyDataSetChanged();
						notiDB.setAllNotiRead();
					} else {
						tabUtil[2].updateTabBadge(++notiCnt);
					}
					break;
				case 10://���� �߰�
					keywordList.add(new KeywordBean(message.obj.toString()));
					keywordAdapter.notifyDataSetChanged();
					ListViewUtils.listViewHeightSet(
							keywordAdapter, lvKeyword);
					break;
					
				case 11://���� ����
					String keyword=message.obj.toString();
					for(int i=keywordList.size()-1;i>=0;i--){
						if(keywordList.get(i).keyword.equals(keyword)){
							keywordList.remove(i);
						}
					}
					keywordAdapter.notifyDataSetChanged();
					ListViewUtils.listViewHeightSet(
							keywordAdapter, lvKeyword);
					break;
					
				case 12://����� �г��� ����
					queryCnt = myQueryDatabase.setTalkList(queryList);
					tabUtil[1].updateTabBadge(queryCnt);
					queryAdapter.notifyDataSetChanged();
					break;
					
				case 13:
					keywordList.clear();
					keywordAdapter.notifyDataSetChanged();
					break;

				default:
					break;
				}

				break;

			default:
				break;
			}
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQ_CODE_GALLERY) {
			if (resultCode == RESULT_OK) {
				Uri uri = data.getData();
				String path = uri.toString();
				Log.e("imagepath", path);

				back = false;
				backUri = path;
				ivBackcustom.setImageURI(uri);
			}
		}
	}
}
