package com.eye.allseeingirc;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.database.QueryLogDatabase;
import com.google.android.gcm.GCMBaseIntentService;

public class GCMIntentService extends GCMBaseIntentService {
	private static final String tag = "GCMIntentService";
	public static final String SEND_ID = "289327804886";

	public GCMIntentService() {
		this(SEND_ID);
	}

	public GCMIntentService(String senderId) {
		super(senderId);
	}

	@Override
	protected void onMessage(final Context context, Intent intent) {

		String type, timestamp, nick, from, chan, msg, collapse_key;
		String temp;
		MyChannelDatabase myChanDB = new MyChannelDatabase(context);
		MyQueryDatabase myQueryDB = new MyQueryDatabase(context);
		try {
			type = URLDecoder.decode(intent.getStringExtra("type").toString(),
					"UTF-8");
			timestamp = URLDecoder.decode(intent.getStringExtra("timestamp")
					.toString(), "UTF-8");
			nick = URLDecoder.decode(intent.getStringExtra("nick").toString(),
					"UTF-8");
			from = URLDecoder.decode(intent.getStringExtra("from").toString(),
					"UTF-8");
			chan = URLDecoder.decode(intent.getStringExtra("chan").toString(),
					"UTF-8");
			msg = URLDecoder.decode(intent.getStringExtra("msg").toString(),
					"UTF-8");
			collapse_key = URLDecoder.decode(
					intent.getStringExtra("collapse_key"), "UTF-8");

			Log.e("GCM PUSH", "type:" + type);
			Log.e("GCM PUSH", "timestamp:" + timestamp);
			Log.e("GCM PUSH", "from:" + from);
			Log.e("GCM PUSH", "msg:" + msg);
			Log.e("GCM PUSH", "nick:" + nick + "//chan:" + chan);

			ActivityManager am = (ActivityManager) context
					.getSystemService(Context.ACTIVITY_SERVICE);
			List<RunningTaskInfo> runList = am.getRunningTasks(10);
			ComponentName name = runList.get(0).topActivity;
			String className = name.getClassName();
			boolean isAppRunning = false;
			if (className.contains("com.eye.allseeingirc")) {
				isAppRunning = true;
			}

			if (isAppRunning == true) {
				final AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
						.getApplicationContext();
				if (type.equals("[��������]")) {
					SharedPreferences pref = getSharedPreferences("pref",
							MODE_PRIVATE);
					SharedPreferences.Editor editor = pref.edit();
					editor.remove("ip");
					editor.remove("first");
					editor.remove("back");
					editor.remove("backres");
					editor.remove("backuri");
					editor.remove("mynick");
					editor.commit();
					KeywordDatabase keywordDB = new KeywordDatabase(context);
					LogDatabase logDB = new LogDatabase(context);
					NotiLogDatabase notiDB = new NotiLogDatabase(context);
					QueryLogDatabase queryDB = new QueryLogDatabase(context);
					keywordDB.deleteAll();
					logDB.deleteAll();
					notiDB.deleteAll();
					queryDB.deleteAll();
					myChanDB.deleteAll();
					myQueryDB.deleteAll();
					Intent mIntent = new Intent(context, SplashActivity.class);
					setNotification(context, "ASIRC ��������", mIntent, "��������",
							"PC���� ������ �����˴ϴ�.", "ASIRC", true);
					System.exit(0);
				} else {
					String channelName=application.remoteClientNetwork.channelName;
					if (channelName == null) {
						String tickerMsg = "";
						Intent mIntent = new Intent(context,
								SplashActivity.class);
						if (type.equals("[ȣ��]")) {
							// ����Ʈ �ѱ�� �κ�
							mIntent.putExtra("noti", 1);// 1�� ä��
							mIntent.putExtra("name", chan);
							tickerMsg = chan + "������ ȣ��";
							if (myChanDB.isAlertOn(chan)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, chan, true);
							}
						} else if (type.equals("[�Ӹ�ȣ��]")) {
							// ����Ʈ �ѱ�� �κ�
							mIntent.putExtra("noti", 2);// 2�� ä��
							mIntent.putExtra("name", nick);
							tickerMsg = nick + "���κ��� ȣ��";
							if (myQueryDB.isAlertOn(nick)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, nick, true);
							}
						} else if (type.equals("[�Ӹ���ȭ]")) {
							mIntent.putExtra("noti", 2);// 2�� ä��
							mIntent.putExtra("name", nick);
							tickerMsg = nick + " : " + msg;
							if (myQueryDB.isAlertOn(nick)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, nick, false);
							}
						}else if (type.equals("[����]")) {
							if(chan.equals("null")){//�ϴ��� ��ȭ
								mIntent.putExtra("noti", 2);// 2�� �ϴ��� ��ȭ
								mIntent.putExtra("name", nick);
								tickerMsg = nick + " : " + msg;
								if (myQueryDB.isAlertOn(nick)) {
									setNotification(context, tickerMsg, mIntent,
											nick, msg, nick, true);
								}
							}else{
								mIntent.putExtra("noti", 1);// 1�� ä��
								mIntent.putExtra("name", chan);
								tickerMsg = nick + " : " + msg;
								if (myChanDB.isAlertOn(chan)) {
									setNotification(context, tickerMsg, mIntent,
											nick, msg, chan, true);
								}
							}
						}
					} else {
						String tickerMsg = "";
						Intent mIntent = new Intent(context,
								SplashActivity.class);
						if (type.equals("[ȣ��]")&&!channelName.equals(chan)) {
							// ����Ʈ �ѱ�� �κ�
							mIntent.putExtra("noti", 1);// 1�� ä��
							mIntent.putExtra("name", chan);
							tickerMsg = chan + "������ ȣ��";
							if (myChanDB.isAlertOn(chan)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, chan, true);
							}
						} else if (type.equals("[�Ӹ�ȣ��]")&&!channelName.equals(nick)) {
							// ����Ʈ �ѱ�� �κ�
							mIntent.putExtra("noti", 2);// 2�� ä��
							mIntent.putExtra("name", nick);
							tickerMsg = nick + "���κ��� ȣ��";
							if (myQueryDB.isAlertOn(nick)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, nick, true);
							}
						} else if (type.equals("[�Ӹ���ȭ]")&&!channelName.equals(nick)) {
							mIntent.putExtra("noti", 2);// 2�� ä��
							mIntent.putExtra("name", nick);
							tickerMsg = nick + " : " + msg;
							if (myQueryDB.isAlertOn(nick)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, nick, false);
							}
						} else if (type.equals("[����]")) {
							if (chan.equals("null")
									&& !channelName.equals(nick)) {// �ϴ��� ��ȭ
								mIntent.putExtra("noti", 2);// 2�� �ϴ��� ��ȭ
								mIntent.putExtra("name", nick);
								tickerMsg = nick + " : " + msg;
								if (myQueryDB.isAlertOn(nick)) {
									setNotification(context, tickerMsg,
											mIntent, nick, msg, nick, true);
								}
							} else {
								if (!!channelName.equals(chan)) {
									mIntent.putExtra("noti", 1);// 1�� ä��
									mIntent.putExtra("name", chan);
									tickerMsg = nick + " : " + msg;
									if (myChanDB.isAlertOn(chan)) {
										setNotification(context, tickerMsg,
												mIntent, nick, msg, chan, true);
									}
								}
							}
						}
					}
				}

			} else {
				if (type.equals("[��������]")) {
					SharedPreferences pref = getSharedPreferences("pref",
							MODE_PRIVATE);
					SharedPreferences.Editor editor = pref.edit();
					editor.remove("ip");
					editor.remove("first");
					editor.putBoolean("back", true);
					editor.putInt("backres", R.drawable.background_5);
					editor.remove("backuri");
					editor.remove("mynick");
					editor.commit();
					KeywordDatabase keywordDB = new KeywordDatabase(context);
					LogDatabase logDB = new LogDatabase(context);
					NotiLogDatabase notiDB = new NotiLogDatabase(context);
					QueryLogDatabase queryDB = new QueryLogDatabase(context);
					keywordDB.deleteAll();
					logDB.deleteAll();
					notiDB.deleteAll();
					queryDB.deleteAll();
					myChanDB.deleteAll();
					myQueryDB.deleteAll();
					Intent mIntent = new Intent(context, SplashActivity.class);
					setNotification(context, "ASIRC ��������", mIntent, "��������",
							"PC���� ������ �����˴ϴ�.", "ASIRC", true);
				} else {
					String tickerMsg = "";
					Intent mIntent = new Intent(context, SplashActivity.class);
					if (type.equals("[ȣ��]")) {
						// ����Ʈ �ѱ�� �κ�
						mIntent.putExtra("noti", 1);// 1�� ä��
						mIntent.putExtra("name", chan);
						tickerMsg = chan + "������ ȣ��";
						if (myChanDB.isAlertOn(chan)) {
							setNotification(context, tickerMsg, mIntent, nick,
									msg, chan, true);
						}
					} else if (type.equals("[�Ӹ�ȣ��]")) {
						// ����Ʈ �ѱ�� �κ�
						mIntent.putExtra("noti", 2);// 2�� ä��
						mIntent.putExtra("name", nick);
						tickerMsg = nick + "���κ��� ȣ��";
						if (myQueryDB.isAlertOn(nick)) {
							setNotification(context, tickerMsg, mIntent, nick,
									msg, nick, true);
						}
					} else if (type.equals("[�Ӹ���ȭ]")) {
						mIntent.putExtra("noti", 2);// 2�� ä��
						mIntent.putExtra("name", nick);
						tickerMsg = nick + " : " + msg;
						if (myQueryDB.isAlertOn(nick)) {
							setNotification(context, tickerMsg, mIntent, nick,
									msg, nick, false);
						}
					} else if (type.equals("[����]")) {
						if(chan.equals("null")){//�ϴ��� ��ȭ
							mIntent.putExtra("noti", 2);// 2�� �ϴ��� ��ȭ
							mIntent.putExtra("name", nick);
							tickerMsg = nick + " : " + msg;
							if (myQueryDB.isAlertOn(nick)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, nick, true);
							}
						}else{
							mIntent.putExtra("noti", 1);// 1�� ä��
							mIntent.putExtra("name", chan);
							tickerMsg = nick + " : " + msg;
							if (myChanDB.isAlertOn(chan)) {
								setNotification(context, tickerMsg, mIntent,
										nick, msg, chan, true);
							}
						}
					}
				}

			}

			// if (myChanDB.isAlertOn(chan)) {
			// Bitmap largeIcon = BitmapFactory.decodeResource(
			// context.getResources(),
			// R.drawable.allseeingirc_icon);
			//
			// PendingIntent pendingIntent = PendingIntent.getActivity(
			// context, 0, mIntent,
			// PendingIntent.FLAG_UPDATE_CURRENT);
			//
			// NotificationCompat.Builder builder = new
			// NotificationCompat.Builder(
			// context).setSmallIcon(R.drawable.allseeingirc_icon)
			// .setLargeIcon(largeIcon).setTicker(tickerMsg)
			// .setContentTitle(nick).setContentText(msg)
			// .setAutoCancel(true);
			//
			// NotificationCompat.BigTextStyle style = new
			// NotificationCompat.BigTextStyle();
			// style.setSummaryText(chan);
			// style.setBigContentTitle(nick);
			// style.bigText(msg);
			//
			// builder.setStyle(style);
			// builder.setContentIntent(pendingIntent);
			//
			// builder.setDefaults(Notification.DEFAULT_VIBRATE);
			// builder.setSound(RingtoneManager
			// .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
			// NotificationManager notificationManager =
			// (NotificationManager) context
			// .getSystemService(Context.NOTIFICATION_SERVICE);
			// notificationManager.notify(0, builder.build());
			// }
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		Log.e("push", "failed");

	}

	@Override
	protected void onError(Context context, String errorId) {// registration�̳�
																// unregistration��
																// ������ �߻���
		Log.d(tag, "onError. errorId : " + errorId);
	}

	@Override
	protected void onRegistered(Context context, String regId) {// gcm server��
																// ��ϵǾ��� �� ȣ����
		// Log.d(tag, "onRegistered. regId : "+regId);
		SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putString("regId", regId);
		editor.commit();

	}

	@Override
	protected void onUnregistered(Context context, String regId) {
		SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove("regId");
		editor.commit();
	}

	@Override
	protected boolean onRecoverableError(Context context, String errorId) {
		Log.d(tag, "onRecoverableError. errorId : " + errorId);
		return super.onRecoverableError(context, errorId);
	}

	private void setNotification(Context context, String tickerMsg,
			Intent mIntent, String title, String text, String summary,
			boolean alert) {
		// if (myChanDB.isAlertOn(chan)) {
		 SharedPreferences pref = getSharedPreferences("pref",
					MODE_PRIVATE);
		Bitmap largeIcon = BitmapFactory.decodeResource(context.getResources(),
				R.drawable.allseeingirc_icon);

		PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,
				mIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		NotificationCompat.Builder builder = new NotificationCompat.Builder(
				context).setSmallIcon(R.drawable.small_noti)
				.setLargeIcon(largeIcon).setTicker(tickerMsg)
				.setContentTitle(title).setContentText(text)
				.setAutoCancel(true).setNumber(pref.getInt("msgcnt", 0)+1);
		SharedPreferences.Editor editor = pref.edit();
		editor.putInt("msgcnt", pref.getInt("msgcnt", 0)+1);
		editor.commit();
		NotificationCompat.BigTextStyle style = new NotificationCompat.BigTextStyle();
		style.setSummaryText(summary);
		style.setBigContentTitle(title);
		style.bigText(text);

		builder.setStyle(style);
		builder.setContentIntent(pendingIntent);

		if (alert) {
			builder.setDefaults(Notification.DEFAULT_VIBRATE);
		builder.setSound(RingtoneManager
				.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
		}
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(0, builder.build());
		// }

	}
}