package com.eye.allseeingirc.utils;

import java.util.Comparator;

import com.eye.allseeingirc.bean.TalkListBean;

public class IndexDescCompare implements Comparator<TalkListBean>{

	@Override
	public int compare(TalkListBean lhs, TalkListBean rhs) {
		return lhs.getIndex()>rhs.getIndex()? -1:lhs.getIndex()<rhs.getIndex()?1:0 ;
	}

}
