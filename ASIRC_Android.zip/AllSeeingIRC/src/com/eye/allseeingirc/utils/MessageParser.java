package com.eye.allseeingirc.utils;

import com.eye.allseeingirc.ChatActivity;
import com.eye.allseeingirc.R;

import android.content.SharedPreferences;
import android.text.Spannable;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;

public class MessageParser {
	
	public static String getDateAndTime(String timestamp) {
		String[] timeArr = timestamp.split("\\.");

		if (timeArr.length == 6) {
			return timeArr[0] + "�� " + timeArr[1] + "�� " + timeArr[2]
					+ "�� " + timeArr[3] + ":" + timeArr[4] + ":"
					+ timeArr[5];
		} else {
			return timestamp;
		}
	}
	
	public static int checkNickMode(String nickName,String userName){
		String nick=nickName;
		int mode=0;
		//0:�Ϲ�/1:@����/2:+���̽�/3:ChanServ
		
		if(nickName.contains("ChanServ"))
			mode=3;
		else if(nickName.contains("@")){
			mode=1;
			nick=nick.replace("@", "");
			if(nickName.contains("+")){
				nickName=nickName.replace("+", "");
				nick=nick.replace("+", "");
			}
		}else if(nickName.contains("+")){
			nick=nick.replace("+", "");
			mode=2;
		}
		if(nick.equals(userName)){
			mode=4;
		}	
	
		
		return mode;
	}
	
	public static void countNickMode(String nickName){
		//0:�Ϲ�/1:@����/2:+���̽�/3:ChanServ
		if(nickName.contains("@")||nickName.contains("@+"))
			ChatActivity.mode_o_count++;
		else if(nickName.contains("+"))
			ChatActivity.mode_v_count++;
		
	}
	
	public static String parseNick(String nickName){
		String returnNick=nickName;
		if(nickName.contains("@"))
			returnNick=nickName.replace("@", "");
		if(nickName.contains("+"))
			returnNick=nickName.replace("+", "");
		
		return returnNick;
	}
	
	public static void setTextViewColorPartial(TextView view, String fulltext, String subtext) {
		view.setText(fulltext, TextView.BufferType.SPANNABLE);
		Spannable str = (Spannable) view.getText();
		int i = fulltext.indexOf(subtext);
		str.setSpan(new ForegroundColorSpan(R.color.orange), i, i + subtext.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
	}

}
