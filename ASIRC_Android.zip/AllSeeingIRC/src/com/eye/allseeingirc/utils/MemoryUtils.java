package com.eye.allseeingirc.utils;

import java.lang.ref.WeakReference;
import java.util.List;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MemoryUtils {

	public static void unbindDrawables(View view) {
		if (view == null) {
			return;
		}
		
		if (view instanceof ImageView) {
			((ImageView) view).setImageDrawable(null);
		}

		if (view.getBackground() != null) {
			view.getBackground().setCallback(null);
		}
		
		if (view instanceof ViewGroup) {
			for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
				unbindDrawables(((ViewGroup) view).getChildAt(i));
			}
			view.setBackgroundResource(0);
			view.setBackgroundDrawable(null);
		}
	}
	
	public static void recursiveRecycle(View root) {
	    if (root == null)
	        return;

	    root.setBackgroundDrawable(null);

	    if (root instanceof ViewGroup) {
	        ViewGroup group = (ViewGroup) root;
	        int count = group.getChildCount();
	        for (int i = 0; i < count; i++) {
	            recursiveRecycle(group.getChildAt(i));
	        }

	        if (!(root instanceof AdapterView)) {
	            group.removeAllViews();
	        }


	    }

	    if (root instanceof ImageView) {
	        ((ImageView) root).setImageDrawable(null);
	    }

	    root = null;

	    return;
	    }

	    public static void recursiveRecycle(List<WeakReference<View>> recycleList) {
	        for (WeakReference<View> ref : recycleList) 
	            recursiveRecycle(ref.get());        
	    }
}
