/*
 * << RemoteClientNetwork >>
 * 
 * - ���� IRC�� ����ϴ� �κ�
 */

package com.eye.allseeingirc.network;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.bean.NotificationBean;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.bean.WhoisBean;
import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.database.QueryLogDatabase;
import com.eye.allseeingirc.utils.MessageParser;

public class RemoteClientNetwork {
	private String ip;
	private int port = 9046;
	public boolean isSocketConnected = false;
	public boolean isPingOn = true;
	public boolean isSplash = false;

	public Socket socket;
	public InetSocketAddress socketAddress;
	public PrintWriter out;
	public InputStream in;
	public Context context;

	public ByteArrayOutputStream baos = new ByteArrayOutputStream();

	public BlockingQueue queue;

	public Handler handler;
	public String channelName;

	private ReceiveRemoteMessage receiveRemoteMessage;
	private MessageHandler msgHandler;
	private SendPing sendPing;

	public RemoteClientNetwork(String ip, Handler handler, String channelName) {
		this.ip = ip;
		this.handler = handler;
		this.channelName = channelName;

		queue = new ArrayBlockingQueue(10000);

		if (ip != null) {
			// msgModi=new MessageModi();
			receiveRemoteMessage = new ReceiveRemoteMessage();
			msgHandler = new MessageHandler();
			sendPing = new SendPing();
		}
	}

	public void setContext(Context context) {
		this.context = context;
	}

	public void receiveMessageOn() {
		// msgModi.start();
		msgHandler.start();
		receiveRemoteMessage.start();
		sendPing.start();

	}

	public void receiveMessageOff() {
		if (receiveRemoteMessage != null && receiveRemoteMessage.isAlive()) {
			isSocketConnected = false;
			receiveRemoteMessage.interrupt();
		}
		if (sendPing != null && sendPing.isAlive()) {
			sendPing.interrupt();
			isPingOn = false;
		}
		if (msgHandler != null && msgHandler.isAlive()) {
			msgHandler.interrupt();
		}
		receiveRemoteMessage = null;
		sendPing = null;
		msgHandler = null;
		socketClose();
	}

	// �޽����� ������ �κ�
	public void sendMessage(String message) {
		if (isSocketConnected) {
			Log.e("sendmsg", message);
			out.println(message);
			out.flush();
		}
	}

	// ������ �޽��� �޴� �κ�
	class ReceiveRemoteMessage extends Thread {
		public void run() {
			socketSetting();// ���� ����

			byte[] buffer = new byte[4096];

			int stx = -1, etx = -1;
			while (isSocketConnected) {
				Log.e("while", "remote start");
				try {
					int size = in.read(buffer);
					if (size != -1) {
						// Log.e("sendmsg before", new String(buffer,0,size));
						if (baos.size() == 0) {
							etx = -1;
							for (int i = 0; i < size; i++) {
								if (buffer[i] == 0x02) {
									stx = i;
									Log.e("ReceiveRemoteMessage", "start : "
											+ stx);
									for (int j = i; j < size; j++) {
										if (buffer[j] == 0x03) {
											etx = j;
											Log.e("ReceiveRemoteMessage",
													"end : " + etx);
											baos.write(buffer, stx, etx - stx
													+ 1);
											String socketMessage = new String(
													baos.toByteArray(), 1,
													baos.size() - 2, "UTF-8");

											Log.i("sendmsg parse",
													socketMessage);
											queue.add(socketMessage);// ť�� �ѱ�
											baos.reset();
											i = j;
											break;
										}
									}
								}
							}
							if (stx > etx) {
								if (etx == -1) {
									baos.write(buffer, 0, size);
								} else {
									baos.write(buffer, stx, size - stx);
								}
							}

						} else {
							int i = 0;
							etx = -1;
							for (int j = i; j < size; j++) {
								if (buffer[j] == 0x03) {
									etx = j;
									Log.e("ReceiveRemoteMessage", "end : "
											+ etx);
									baos.write(buffer, 0, etx + 1);
									String socketMessage = new String(
											baos.toByteArray(), 1,
											baos.size() - 2, "UTF-8");

									Log.i("sendmsg parse", socketMessage);
									queue.add(socketMessage);// ť�� �ѱ�
									baos.reset();
									i = j;
									break;
								}
							}
							for (; i < size; i++) {
								if (buffer[i] == 0x02) {
									stx = i;
									Log.e("ReceiveRemoteMessage", "start : "
											+ stx);
									for (int j = i; j < size; j++) {
										if (buffer[j] == 0x03) {
											etx = j;
											Log.e("ReceiveRemoteMessage",
													"end : " + etx);
											baos.write(buffer, stx, etx - stx
													+ 1);
											String socketMessage = new String(
													baos.toByteArray(), 1,
													baos.size() - 2, "UTF-8");

											Log.i("sendmsg parse",
													socketMessage);
											queue.add(socketMessage);// ť�� �ѱ�
											baos.reset();
											i = j;
											break;
										}
									}
								}
							}
							if (stx > etx) {
								if (etx == -1) {
									baos.write(buffer, 0, size);
								} else {
									baos.write(buffer, stx, size - stx);
								}
							}
						}

					} else {

						if (channelName == null) {
							handler.sendEmptyMessage(1);
						}
						// ���� ���� ������ �� ó���� ���ָ� ���� ��!
						isSocketConnected = false;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			isPingOn = false;
			Log.e("exit", "whilereceive exit");

		}
	}

	class MessageHandler extends Thread {
		public void run() {

			while (isPingOn) {
				Log.e("while", "msghandler start");
				String fullMsg;
				try {
					fullMsg = queue.take().toString();
					Message handleMsg = new Message();
					try {
						handleMsg.what = 5;
						Log.e("queue", "ok..");
						String type, time, chan, nick, msg;
						Object obj;
						Object objChan;
						int type_num;
						JSONObject jsonObj = new JSONObject(fullMsg);
						type = jsonObj.getString("type");
						time = MessageParser.getDateAndTime(jsonObj
								.getString("timestamp"));
						chan = jsonObj.getString("chan");
						nick = jsonObj.getString("nick");
						msg = jsonObj.getString("msg");
						obj = jsonObj.get("msg");
						objChan = jsonObj.get("chan");
						if (type.equals("[����]")) {// 3�� �ϴû�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(3, chan, nick, time, nick
									+ "���� �����ϼ̽��ϴ�.");
							if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {
								MyChannelDatabase chanDB = new MyChannelDatabase(
										context);
								chanDB.updatePeopleIn(chan);
								if (chan.equals(channelName)) {// ������ ������Ʈ
									handleMsg.arg1 = 8;
									handleMsg.obj = new BubbleBean(3, nick,
											time, nick + "���� �����ϼ̽��ϴ�.");
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {// ���� ������
									handleMsg.arg1 = 0;
									handleMsg.obj = chan;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[����]")) {// 3�� �ϴû�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(3, chan, nick, time, nick
									+ "���� �����ϼ̽��ϴ�.");
							if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {
								MyChannelDatabase chanDB = new MyChannelDatabase(
										context);
								chanDB.updatePeopleOut(chan);
								if (chan.equals(channelName)) {// ������ ������Ʈ
									handleMsg.arg1 = 8;
									handleMsg.obj = new BubbleBean(3, nick,
											time, nick + "���� �����ϼ̽��ϴ�.");
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {// ���� ������
									handleMsg.arg1 = 1;
									handleMsg.obj = chan;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[��ȭ]")) {// 1�� ���� ������ ��
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(1, chan, nick, time, msg);

							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(1, nick, time,
										msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// ���� ������
								MyChannelDatabase chanDB = new MyChannelDatabase(
										context);
								chanDB.updateChanUnread(chan);

								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									TalkListBean data = new TalkListBean();
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(chan);
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[����ȭ]")) {// 2�� ���� ������ ��
							SharedPreferences pref = context
									.getSharedPreferences("pref",
											Context.MODE_PRIVATE);
							nick = pref.getString("mynick", "");
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(2, chan, nick, time, msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(2, nick, time,
										msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// ���� ������ ������
							// MyChannelDatabase chanDB = new MyChannelDatabase(
							// context);
							// chanDB.updateChanUnread(chan);

								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									TalkListBean data = new TalkListBean();
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(chan);
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[ȣ��]")) {

							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(2, chan, nick, time, msg);
							if (channelName == null && handler != null
									&& !isSplash) {// ������
								MyChannelDatabase chanDB = new MyChannelDatabase(
										context);
								chanDB.updateChanUnread(chan);
								TalkListBean data = new TalkListBean();
								data.setLatestMsg(msg);
								data.setLatestTime(time);
								data.setChanName(chan);
								data.isChan = true;
								handleMsg.arg1 = 2;
								handleMsg.obj = data;
								handler.sendMessage(handleMsg);
							} else if (channelName != null
									&& !channelName.equals(chan)// �ش�ä����
									&& handler != null) {

								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(2, nick, time,
										msg);
								handler.sendMessage(handleMsg);
							} else if (isSplash && handler != null) {
								handler.sendMessage(handleMsg);
							}
							Message notiMsg = new Message();
							notiMsg.what = 5;
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(5, chan, nick, type + " "
									+ nick + " : " + msg, time);
							if (channelName == null && handler != null
									&& !isSplash) {
								notiMsg.arg1 = 9;
								NotificationBean data = new NotificationBean();
								data.setType(5);
								data.setIsChecked(false);
								data.setMsg(type + " " + nick + " : " + msg);
								data.setTimestamp(time);
								notiMsg.obj = data;
								handler.sendMessage(notiMsg);
							} else if (channelName != null
									&& !channelName.equals(chan)
									&& handler != null) {
								notiMsg.arg1 = 7;
								notiMsg.obj = type + " " + nick + " : " + msg;
								handler.sendMessage(notiMsg);
							}
						} else if (type.equals("[����]")) {
							// ���� ȿ���� �ش�.
							if (chan.equals("null")) {// �ϴ��� ��ȭ ����
								QueryLogDatabase logDB = new QueryLogDatabase(
										context);
								logDB.insertQueryLogDatabase(nick, 2, msg, time);
								if (channelName == null && handler != null
										&& !isSplash) {// ������
									MyQueryDatabase queryDB = new MyQueryDatabase(
											context);
									queryDB.updateQueryUnread(nick);
									TalkListBean data = new TalkListBean();
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(nick);
									data.isChan = false;
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);

								} else if (channelName != null
										&& !channelName.equals(nick)
										&& handler != null) {// �ش� ������
									handleMsg.arg1 = 8;
									handleMsg.obj = new BubbleBean(2, nick,
											time, msg);
									handler.sendMessage(handleMsg);
								} else if (isSplash && handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// �׳� ä��
								LogDatabase logDB = new LogDatabase(context,
										chan);
								logDB.insertLog(2, chan, nick, time, msg);
								if (channelName == null && handler != null
										&& !isSplash) {
									MyChannelDatabase chanDB = new MyChannelDatabase(
											context);
									chanDB.updateChanUnread(chan);
									TalkListBean data = new TalkListBean();
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(chan);
									data.isChan = true;
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);

								} else if (channelName != null
										&& !channelName.equals(chan)
										&& handler != null) {
									handleMsg.arg1 = 8;
									handleMsg.obj = new BubbleBean(2, nick,
											time, msg);
									handler.sendMessage(handleMsg);
								} else if (isSplash && handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
							Message notiMsg = new Message();
							notiMsg.what = 5;
							type = "[Ű����]";
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(5, chan, nick, type + " "
									+ nick + " : " + msg, time);
							if (channelName == null && handler != null
									&& !isSplash) {
								notiMsg.arg1 = 9;
								NotificationBean data = new NotificationBean();
								data.setType(5);
								data.setIsChecked(false);
								data.setMsg(type + " " + nick + " : " + msg);
								data.setTimestamp(time);
								notiMsg.obj = data;
								handler.sendMessage(notiMsg);
							} else if (channelName != null
									&& !channelName.equals(chan)
									&& handler != null) {
								notiMsg.arg1 = 7;
								notiMsg.obj = type + " " + nick + " : " + msg;
								handler.sendMessage(notiMsg);
							}
						} else if (type.equals("[ä�θ��]")) {// 5�� �ʷϻ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ��� ���� : " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ��� ���� : " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[��]")) {// 5�� �ʷϻ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ��� ���� : +o " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ��� ���� : +o " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[���]")) {// 5�� �ʷϻ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ��� ���� : -o " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ��� ���� : -o " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[���̽�]")) {// 5�� �ʷϻ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ��� ���� : +v " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ��� ���� : +v " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[���̽�]")) {// 5�� �ʷϻ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ��� ���� : -v " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ��� ���� : -v " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[���Ⱥ���]")) {// 5�� �ʷϻ� �� ����
															// ����ó�� ����ֱ�
							LogDatabase logDB = new LogDatabase(context, chan);
							logDB.insertLog(5, chan, nick, time, nick
									+ "���� ���Ⱥ��� : " + msg);
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(5, nick, time,
										nick + "���� ���Ⱥ��� : " + msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
								handleMsg.arg1 = 9;
								handleMsg.obj = msg;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[�ʴ�]")) {
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(3, chan, nick, nick + "���� "
									+ chan + "���� �ʴ��ϼ̽��ϴ�.", time);
							if (channelName == null && handler != null
									&& !isSplash) {
								handleMsg.arg1 = 9;
								NotificationBean data = new NotificationBean();
								data.setIsChecked(false);
								data.setChan(chan);
								data.setType(3);
								data.setMsg(nick + "���� " + chan + "���� �ʴ��ϼ̽��ϴ�.");
								data.setTimestamp(time);
								handleMsg.obj = data;
								handler.sendMessage(handleMsg);
							} else if (channelName != null && handler != null) {
								handleMsg.arg1 = 7;
								handleMsg.obj = nick + "���� " + chan
										+ "���� �ʴ��ϼ̽��ϴ�.";
								handler.sendMessage(handleMsg);
							} else if (isSplash) {
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[�Ӹ���ȭ]")) {
							QueryLogDatabase logDB = new QueryLogDatabase(
									context);
							logDB.insertQueryLogDatabase(nick, 1, msg, time);
							if (nick.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(1, nick, time,
										msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// ���� ������
								MyQueryDatabase queryDB = new MyQueryDatabase(
										context);
								queryDB.updateQueryUnread(nick);
								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									TalkListBean data = new TalkListBean();
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(nick);
									data.isChan = false;
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[��ȭ������]")) {
							MyQueryDatabase myQueryDB = new MyQueryDatabase(
									context);
							myQueryDB.updateUsername(nick, msg);
							if (nick.equals(channelName)) {
								handleMsg.arg1 = 9;
								handleMsg.obj = msg;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else if (channelName == null) {
								handleMsg.arg1 = 12;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
							Message notiMsg = new Message();
							notiMsg.what = 5;
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(6, "", nick, nick
									+ "���� �г����� ����Ǿ����ϴ�. : " + msg, time);
							if (channelName == null && handler != null) {
								if (isSplash) {
									handler.sendMessage(notiMsg);

								} else {
									notiMsg.arg1 = 9;
									NotificationBean data = new NotificationBean();
									data.setType(6);
									data.setIsChecked(false);
									data.setMsg(nick + "���� �г����� ����Ǿ����ϴ�. : "
											+ msg);
									data.setTimestamp(time);
									notiMsg.obj = data;
									handler.sendMessage(notiMsg);
								}
							} else if (channelName != null && handler != null) {
								notiMsg.arg1 = 7;
								notiMsg.obj = nick + "���� �г����� ����Ǿ����ϴ�. : "
										+ msg;
								handler.sendMessage(notiMsg);
							}
						} else if (type.equals("[�Ӹ�ȣ��]")) {
							QueryLogDatabase logDB = new QueryLogDatabase(
									context);
							logDB.insertQueryLogDatabase(nick, 4, msg, time);
							if (nick.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(4, nick, time,
										msg);
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// ���� ������
								MyQueryDatabase queryDB = new MyQueryDatabase(
										context);
								queryDB.updateQueryUnread(nick);
								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									TalkListBean data = new TalkListBean();
									data.isChan = false;
									data.setLatestMsg(msg);
									data.setLatestTime(time);
									data.setChanName(nick);
									handleMsg.arg1 = 2;
									handleMsg.obj = data;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
							Message notiMsg = new Message();
							notiMsg.what = 5;
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(4, "", nick, nick
									+ "�����κ��� ȣ�� : " + msg, time);
							if (channelName == null && handler != null
									&& !isSplash) {
								notiMsg.arg1 = 9;
								NotificationBean data = new NotificationBean();
								data.setType(4);
								data.setIsChecked(false);
								data.setMsg(nick + "�����κ��� ȣ�� : " + msg);
								data.setTimestamp(time);
								notiMsg.obj = data;
								handler.sendMessage(notiMsg);
							} else if (channelName != null
									&& !channelName.equals(nick)
									&& handler != null) {
								notiMsg.arg1 = 7;
								notiMsg.obj = nick + "�����κ��� ȣ�� : " + msg;
								handler.sendMessage(notiMsg);
							}
						} else if (type.equals("[����]")) {// �佺Ʈ�� ���� ��Ͽ� ����
							// LogDatabase logDB = new LogDatabase(context,
							// chan);
							if (msg.equals("null")) {
								msg = "";
							}
							// logDB.insertLog(3, chan, nick, time, nick
							// + "���� �����ϼ̽��ϴ�." + msg);

							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(1, "", nick, nick
									+ "���� �����ϼ̽��ϴ�. " + msg, time);
							if (channelName == null && handler != null) {
								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									handleMsg.arg1 = 9;
									NotificationBean data = new NotificationBean();
									data.setType(1);
									data.setIsChecked(false);
									data.setMsg(nick + "���� �����ϼ̽��ϴ�. " + msg);
									data.setTimestamp(time);
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);
								}
							} else if (channelName != null && handler != null) {
								handleMsg.arg1 = 7;
								handleMsg.obj = nick + "���� �����ϼ̽��ϴ�. " + msg;
								handler.sendMessage(handleMsg);
							}

						} else if (type.equals("[ä�θ��]")) {
							MyChannelDatabase myChannelDatabase = new MyChannelDatabase(
									context);
							if (obj.equals(null)) {
								Log.e("null", type);
								myChannelDatabase.updateChanOnOff(null);
							} else {
								String[] chanList = msg.split(",");
								myChannelDatabase.updateChanOnOff(chanList);

							}
							handleMsg.arg1 = 5;
							if (handler != null) {
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[�и��1]")
								|| type.equals("[�и��2]")
								|| type.equals("[�и��3]")
								|| type.equals("[�и��4]")
								|| type.equals("[�и��5]")) {
							handleMsg.arg1 = 10;
							handleMsg.arg2 = Integer.parseInt(nick);
							handleMsg.obj = msg;
							if (handler != null) {
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[����]")) {
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(2, "", nick, type + " "
									+ msg, time);
							if (channelName == null && handler != null) {
								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									handleMsg.arg1 = 9;
									NotificationBean data = new NotificationBean();
									data.setType(2);
									data.setIsChecked(false);
									data.setMsg(type + " " + msg);
									data.setTimestamp(time);
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);
								}
							} else if (channelName != null && handler != null) {
								handleMsg.arg1 = 7;
								handleMsg.obj = msg;
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[�˸�]")) {
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(2, "", nick, type + " "
									+ nick + msg, time);
							if (channelName == null && handler != null) {
								if (isSplash) {
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									handleMsg.arg1 = 9;
									NotificationBean data = new NotificationBean();
									data.setType(2);
									data.setIsChecked(false);
									data.setMsg(type + " " + nick + msg);
									data.setTimestamp(time);
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);
								}
							} else if (channelName != null && handler != null) {
								handleMsg.arg1 = 7;
								handleMsg.obj = nick + msg;
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[������]")) {
							MyChannelDatabase myChannelDatabase = new MyChannelDatabase(
									context);
							if (chan.equals(channelName)) {// ������ ������Ʈ

							} else {// ���� ������ ������
								boolean flag = myChannelDatabase
										.insertChannel(chan, true, true,
												Integer.parseInt(msg));
								handleMsg.arg1 = 3;
								TalkListBean data = new TalkListBean(chan,
										Integer.parseInt(msg));
								handleMsg.obj = data;
								if (flag) {
									handleMsg.arg2 = 0;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								} else {
									handleMsg.arg2 = 1;
									if (handler != null) {
										handler.sendMessage(handleMsg);
									}
								}
							}
						} else if (type.equals("[������]")) {
							MyChannelDatabase myChannelDatabase = new MyChannelDatabase(
									context);
							if (myChannelDatabase.checkChannel(chan)) {
								myChannelDatabase.setChanOnOff(chan, false);
							}
							LogDatabase logDB = new LogDatabase(context);
							logDB.insertLog(10, chan, "", time, "");
							if (chan.equals(channelName)) {// ������ ������Ʈ
								handleMsg.arg1 = 8;
								handleMsg.obj = new BubbleBean(10, "", time, "");
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {// ���� ������ ������
								handleMsg.arg1 = 4;
								handleMsg.obj = chan;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[��������]")) {

							if (!msg.equals("\u0000")) {
								// if (chan.equals(channelName)) {// ������
								// ������Ʈ
								handleMsg.arg1 = 9;
								handleMsg.obj = msg;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
								// }
							}
						} else if (type.equals("[���г���]")) {
							SharedPreferences pref = context
									.getSharedPreferences("pref",
											Context.MODE_PRIVATE);
							SharedPreferences.Editor editor = pref.edit();
							editor.putString("mynick", msg);
							editor.commit();

							if (channelName == null && handler != null) {
								handleMsg.arg1 = 8;
								handleMsg.obj = msg;
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[����ȭ������]")) {
							SharedPreferences pref = context
									.getSharedPreferences("pref",
											Context.MODE_PRIVATE);
							SharedPreferences.Editor editor = pref.edit();
							editor.putString("mynick", msg);
							editor.commit();
							// if(channelName==null&&handler!=null){
							// handleMsg.arg1=8;
							// handleMsg.obj=msg;
							// handler.sendMessage(handleMsg);
							// }
							if (channelName == null) {
								handleMsg.arg1 = 8;
								handleMsg.obj = msg;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}
							} else {
								handleMsg.arg1 = 7;
								handleMsg.obj = "�г����� ����Ǿ����ϴ�. : " + msg;
								if (handler != null) {
									handler.sendMessage(handleMsg);
								}

							}

						} else if (type.equals("[��Ƽ��]")) {
							NotiLogDatabase notiDB = new NotiLogDatabase(
									context);
							notiDB.insertNewNotiLog(7, "", nick, nick + " : "
									+ msg, time);
							if (channelName == null && handler != null) {
								if (isSplash) {
									handler.sendMessage(handleMsg);
								} else {
									handleMsg.arg1 = 9;
									NotificationBean data = new NotificationBean();
									data.setType(2);
									data.setIsChecked(false);
									data.setMsg(nick + msg);
									data.setTimestamp(time);
									handleMsg.obj = data;
									handler.sendMessage(handleMsg);
								}
							} else if (channelName != null && handler != null) {
								handleMsg.arg1 = 7;
								handleMsg.obj = nick + msg;
								handler.sendMessage(handleMsg);
							}
						} else if (type.equals("[�����߰�]")) {
							KeywordDatabase keywordDB = new KeywordDatabase(
									context);
							if (keywordDB.insertKeyword(msg)) {
								if (channelName == null && handler != null) {
									if (isSplash) {
										handler.sendMessage(handleMsg);
									} else {
										handleMsg.arg1 = 10;
										handleMsg.obj = msg;
										handler.sendMessage(handleMsg);
									}
								}
							} else {
								if (handler != null) {
									handleMsg.arg1 = 7;
									handleMsg.obj = "�̹� �߰��� Ű�����Դϴ�.";
									handler.sendMessage(handleMsg);
								}
							}
						} else if (type.equals("[��������]")) {
							if (msg.equals("N###")) {
								KeywordDatabase keywordDB = new KeywordDatabase(
										context);
								keywordDB.deleteAll();
								if (channelName == null && handler != null) {
									if (isSplash) {
										handler.sendMessage(handleMsg);
									} else {
										handleMsg.arg1 = 13;
										handler.sendMessage(handleMsg);
									}
								}
							} else {
								KeywordDatabase keywordDB = new KeywordDatabase(
										context);
								keywordDB.deletetKeyword(msg);
								if (channelName == null && handler != null) {
									if (isSplash) {
										handler.sendMessage(handleMsg);
									} else {
										handleMsg.arg1 = 11;
										handleMsg.obj = msg;
										handler.sendMessage(handleMsg);
									}
								}
							}

						}

					} catch (JSONException e) {
						String address, name, chanlist, server, state, idle, time, auth;
						try {// whois ���� �� �޽����� �޾��� ��
							JSONObject userJson = new JSONObject(fullMsg);
							address = userJson.getString("address");
							name = userJson.getString("name");
							chanlist = userJson.getString("chanlist");
							server = userJson.getString("server");
							state = userJson.getString("state");
							idle = userJson.getString("idle");
							time = userJson.getString("time");
							auth = userJson.getString("auth");
							ArrayList<WhoisBean> whoisArrayList = new ArrayList<WhoisBean>();
							whoisArrayList.add(new WhoisBean("IP", address));
							whoisArrayList.add(new WhoisBean("����ڸ�", name));
							if (!chanlist.equals("����")) {
								whoisArrayList.add(new WhoisBean("�Խ�ä��",
										chanlist));
							}
							whoisArrayList.add(new WhoisBean("���Ӽ���", server));
							if (!state.equals("����")) {
								whoisArrayList
										.add(new WhoisBean("�������", state));
							}
							whoisArrayList.add(new WhoisBean("���޽ð�", idle));
							whoisArrayList.add(new WhoisBean("�����Ͻ�", time));
							if (!auth.equals("����")) {
								whoisArrayList.add(new WhoisBean("��������", auth));
							}
							handleMsg.arg1 = 11;
							handleMsg.obj = whoisArrayList;
							if (handler != null) {
								handler.sendMessage(handleMsg);
							}
						} catch (JSONException e1) {
							e1.printStackTrace();
							Log.e("JSON", "json exception");
							if (isSplash) {
								if (handler != null) {
									Message msgMessage = new Message();
									msgMessage.what = 100;
									msgMessage.arg1 = Integer.parseInt(fullMsg);
									handler.sendMessage(msgMessage);
								}
							}
						}
					}
				} catch (InterruptedException e2) {
					e2.printStackTrace();
				}

			}
			Log.e("exit", "whilemsgparse exit");
		}
	}

	class SendPing extends Thread {
		public void run() {
			while (isPingOn) {
				Log.e("while", "heartbeat start");
				if (isSocketConnected) {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					out.println("{\"message\":\"[HEARTBEAT]\"}");
					out.flush();
				} else {
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			Log.e("exit", "whileping exit");
		}
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	private void socketSetting() {// ���� ���� �Լ�
		try {
			socketAddress = new InetSocketAddress(ip, port);
			socket = new Socket();
			socket.connect(socketAddress, 3000);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = socket.getInputStream();
			isSocketConnected = socket.isConnected();
			JSONObject settingMsg = new JSONObject();
			try {
				settingMsg.put("message", "/chan_list");
				sendMessage(settingMsg.toString());
			} catch (JSONException e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(500);
				settingMsg.put("message", "/my_nick");
				sendMessage(settingMsg.toString());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (JSONException e) {
				e.printStackTrace();
			}
			if (channelName == null) {
				if (isSocketConnected && handler != null) {
					handler.sendEmptyMessage(0);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			isSocketConnected = false;
			if (channelName == null && handler != null) {
				handler.sendEmptyMessage(1);
			}
		}
	}

	private void socketClose() {// ���� �ݴ� �Լ�
		if (out != null) {
			JSONObject jsonObject = new JSONObject();
			try {
				jsonObject.put("message", "Bye Bye");
			} catch (JSONException e) {
				e.printStackTrace();
			}
			out.print(jsonObject.toString());
			out.flush();
			out.close();
		}
		if (in != null) {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (socket != null) {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (handler != null) {
			handler.sendEmptyMessage(1);
		}
	}
}