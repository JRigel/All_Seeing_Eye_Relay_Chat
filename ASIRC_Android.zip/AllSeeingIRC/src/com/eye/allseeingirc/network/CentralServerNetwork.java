/*
 * << CentralServerNetwork >>
 * 
 * - �߾� ������ ����ϴ� �κ�
 */

package com.eye.allseeingirc.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.eye.allseeingirc.bean.PopChanBean;
import com.google.android.gcm.GCMRegistrar;

public class CentralServerNetwork {
	private String serverIP = "210.118.69.193";
	private int serverPortNum = 5001;
	private boolean isSocketConnected = true;
	String remoteIP;
	String regId;

	public InetSocketAddress socketAddress = null;
	public Socket socket = null;
	public PrintWriter out = null;
	public InputStream in = null;

	private String jsonString;
	private byte[] buffer = new byte[2048];
	private JSONArray jsonArray;

	public Context context;
	public Handler handler;
	public ArrayList<PopChanBean> popList;
	
	ReceivePopChanList receivePopChanList;
	UserAuth userAuth;

	public CentralServerNetwork(Context context, Handler handler) {
		this.handler = handler;
		this.context = context;
	}

	public boolean getSocketConnected() {
		return isSocketConnected;
	}

	public String getRemoteIP() {
		return remoteIP;
	}

	public void getPopChanList(ArrayList<PopChanBean> popList) {
		this.popList = popList;
		receivePopChanList = new ReceivePopChanList();
		receivePopChanList.setDaemon(true);
		receivePopChanList.start();
	}

	public void userAuthenticator(String regId) {
		this.regId=regId;
		userAuth = new UserAuth();
		userAuth.setDaemon(true);
		userAuth.start();
	}

	class UserAuth extends Thread {

		public void run() {
			socketSetting();// ���� ����
			if (isSocketConnected) {
				out.println("1&" + regId);// ������ ��û
				try {
					int size = in.read(buffer);
					if (size != -1) {
						String authNum = new String(buffer, 0, size, "UTF-8");
						Log.e("authNum", authNum);
						Message handleMsg = new Message();
						handleMsg.what = 0;
						handleMsg.obj = authNum.replace("\n", "");
						handler.sendMessage(handleMsg);
						int readSize = in.read(buffer);
						Log.e("readSize", readSize + "");
						if (readSize != -1) {
							String authIP = new String(buffer, 0, readSize,
									"UTF-8");
							Log.e("authIP", authIP);
							Message handleMsgIP = new Message();
							handleMsgIP.what = 3;
							handleMsgIP.obj = authIP.replace("\n", "").replace("\r", "");
							
							handler.sendMessage(handleMsgIP);
							out.println("99");
						}
					}

				} catch (IOException e) {
					e.printStackTrace(); 
					handler.sendEmptyMessage(1);
				}
				socketClose();// ���� ����
			} else {
				handler.sendEmptyMessage(1);
			}
			Log.e("authEnd", "��!!");
		}
	}

	class ReceivePopChanList extends Thread {

		public void run() {
			socketSetting();// ���� ����
			if (isSocketConnected) {
				out.println(2);// ������ ��û
				try {
					popList.clear();
					int size = in.read(buffer);
					jsonString = new String(buffer, 0, size, "UTF-8");
					Log.e("tag", jsonString);
					jsonArray = new JSONArray(jsonString);
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						popList.add(new PopChanBean(true, jsonObject
								.getString("channel"), jsonObject
								.getString("topic"), jsonObject.getInt("user")));
					}
				} catch (IOException e) {
					e.printStackTrace();
				} catch (JSONException e) {
					e.printStackTrace();
				}
				socketClose();// ���� ����
				handler.sendEmptyMessage(0);
			}
		}
	}

	private void socketSetting() {// ���� ���� �Լ�
		try {
			socketAddress = new InetSocketAddress(serverIP, serverPortNum);
			socket = new Socket();
			socket.connect(socketAddress, 5000);

			out = new PrintWriter(socket.getOutputStream(), true);
			in = socket.getInputStream();
		} catch (IOException e) {
			isSocketConnected = false;
			e.printStackTrace();
		}
	}

	private void socketClose() {// ���� �ݴ� �Լ�
		if (out != null) {
			out.close();
		}
		if (in != null) {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (socket != null) {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void setThreadStop(){
		if(userAuth!=null&&userAuth.isAlive()){
			userAuth.interrupt();
			userAuth=null;
		}
	}
}