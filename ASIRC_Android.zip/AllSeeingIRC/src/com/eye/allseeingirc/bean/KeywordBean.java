package com.eye.allseeingirc.bean;

public class KeywordBean {
	public String keyword;
	public boolean isChecked;
	
	public KeywordBean(String keyword) {
		this.keyword=keyword;
		isChecked=false;
	}
}
