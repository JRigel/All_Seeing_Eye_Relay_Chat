/*
 * << PopChanBean >>
 * - �α� ä���� �����ֱ� ���� ������ ��
 */

package com.eye.allseeingirc.bean;

public class PopChanBean {
	boolean isSubOn;
	String chanName;
	String topic;
	int subscribeCount;
	
	public PopChanBean(boolean isSubOn,String chanName,String topic,int subscribeCount){
		this.isSubOn=isSubOn;
		this.chanName=chanName;
		this.topic=topic;
		this.subscribeCount=subscribeCount;
	}
	
	public boolean getIsSubOn(){
		return isSubOn;
	}
	
	public String getChanName(){
		return chanName;
	}
	
	public String getTopic(){
		return topic;
	}
	
	public int getSubCount(){
		return subscribeCount;
	}
	
	public void setIsSubOn(boolean isSubOn){
		this.isSubOn=isSubOn;
	}
}
