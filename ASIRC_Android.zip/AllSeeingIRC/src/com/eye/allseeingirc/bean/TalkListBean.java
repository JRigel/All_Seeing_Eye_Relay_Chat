package com.eye.allseeingirc.bean;

public class TalkListBean {
	String chanName;
	int count;
	String latestTime="----�� --�� --�� --:--:--";
	String latestMsg="�޽����� �����ϴ�.";
	boolean isSubOn;
	boolean isAlertable;
	int badge;
	int index;
	public boolean isChan=true;
	
	public TalkListBean(){
		count=0;
		isAlertable=true;
		isSubOn=true;
		index=-1;
		badge=0;
	}
	public TalkListBean(String chanName,int count){
		this.count=count;
		this.chanName=chanName;
		isAlertable=true;
		isSubOn=true;
		index=-1;
		badge=0;
	}
	
	public int getBadge(){
		return this.badge;
	}
	
	public String getChanName() {
		return this.chanName;
	}
	
	public int getCount(){
		return this.count;
	}
	
	public String getLatestTime(){
		return this.latestTime;
	}
	
	public String getLatestMsg(){
		return this.latestMsg;
	}
	
	public boolean getIsSubOn(){
		return this.isSubOn;
	}
	
	public boolean getIsAlertable(){
		return this.isAlertable;
	}
	
	public int getIndex(){
		return this.index;
	}
	
	public void setChanName(String chanName){
		this.chanName=chanName;
	}
	
	public void setCount(int count){
		this.count=count;
	}
	
	public void setLatestTime(String latestTime){
		this.latestTime=latestTime;
	}
	
	public void setLatestMsg(String latestMsg){
		this.latestMsg=latestMsg;
	}
	
	public void setIsSubOn(boolean isSubOn){
		this.isSubOn=isSubOn;
	}
	
	public void setIsAlertable(boolean isAlertable){
		this.isAlertable=isAlertable;
	}
	
	public void setIndex(int index){
		this.index=index;
	}
	
	public void setBadge(int badge){
		this.badge=badge;
	}
}
