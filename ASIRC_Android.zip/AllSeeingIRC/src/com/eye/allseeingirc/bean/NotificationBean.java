package com.eye.allseeingirc.bean;

public class NotificationBean {
	int type;
	String timestamp;
	String nick;
	String chan;
	String msg;
	boolean isChecked;
	
	public NotificationBean(){
		
	}
	
	public void setType(int type){
		this.type=type;
	}
	
	public void setTimestamp(String timestamp){
		this.timestamp=timestamp;
	}
	
	public void setNick(String nick){
		this.nick=nick;
	}
	
	public void setChan(String chan){
		this.chan=chan;
	}
	
	public void setMsg(String msg){
		this.msg=msg;
	}
	
	public void setIsChecked(boolean isChecked){
		this.isChecked=isChecked;
	}
	
	public int getType(){
		return this.type;
	}
	
	public String getTimestamp(){
		return timestamp;
	}
	
	public String getNick(){
		return nick;
	}
	
	public String getChan(){
		return chan;
	}
	
	public String getMsg(){
		return msg;
	}
	
	public boolean getIsChecked(){
		return isChecked;
	}

}
