package com.eye.allseeingirc.bean;

public class WhoisBean {
	String key;
	String value;
	
	public WhoisBean(String key,String value){
		this.key=key;
		this.value=value;
	}
	
	public String getKey(){
		return key;
	}
	
	public String getValue(){
		return value;
	}

}
