package com.eye.allseeingirc.view;

import android.widget.TextView;

public class TypeHolder {
	public TextView message;
	public TextView time;
	public TextView name;
	public int mode;
}
