package com.eye.allseeingirc.view;

import android.view.View;
import android.view.ViewGroup;

public class ViewUtils {

	public static boolean checkFocusRec(View view) {
	    if (view.isFocused()){
	    	view.clearFocus();
	        return true;
	    }
	    if (view instanceof ViewGroup) {
	        ViewGroup viewGroup = (ViewGroup) view;
	        for (int i = 0; i < viewGroup.getChildCount(); i++) {
	            if (checkFocusRec(viewGroup.getChildAt(i)))
	                return true;
	        }
	    }
	    return false;
	}
}
