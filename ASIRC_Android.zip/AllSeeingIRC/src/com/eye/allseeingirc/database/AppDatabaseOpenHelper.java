package com.eye.allseeingirc.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseOpenHelper extends SQLiteOpenHelper{

	public AppDatabaseOpenHelper(Context context, String name,
			CursorFactory factory, int version) {
		super(context, name, factory, version);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String chatList="create table chat_list"+
				" (id integer primary key autoincrement"+
				", channel text unique"
				+ ", topic boolean true"
				+", onoff boolean true"
				+ ",alert boolean true"
				+ ",unread integer"
				+ ",count integer)";
		String chatLog="create table chat_log"+
				" (id integer primary key autoincrement"+
				", chan text"+
				", mode integer"+
				", nickname text"+
				", contents text"+
				", time text)";
		String queryList="create table query_list"+
				" (id integer primary key autoincrement"+
				", username text unique"
				+ ",alert boolean true"
				+ ",unread integer)";
		String queryLog="create table query_log"+
				" (id integer primary key autoincrement"+
				", queryid integer"+
				", mode integer"+
				", nickname text"+
				", contents text"+
				", time text)";
		String notiLog="create table noti_log"+
				" (id integer primary key autoincrement"+
				", type integer"+
				", chan text"+
				", nickname text"+
				", contents text"+
				", ischecked boolean false"+
				", time text)";
		String keyword="create table keyword_list"
				+ "(id integer primary key autoincrement"
				+ ", keyword text unique)";
		db.execSQL(chatList);
		db.execSQL(chatLog);
		db.execSQL(queryList);
		db.execSQL(queryLog);
		db.execSQL(notiLog);
		db.execSQL(keyword);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		String chatList="drop table if exists chat_list";
		String chatLog="drop table if exists chat_log";
		String queryList="drop table if exists query_list";
		String queryLog="drop table if exists query_log";
		String notiLog="drop table if exists noti_log";
		String keyword="drop table if exists keyword_list";
		db.execSQL(chatList);
		db.execSQL(chatLog);
		db.execSQL(queryList);
		db.execSQL(queryLog);
		db.execSQL(notiLog);
		db.execSQL(keyword);
		onCreate(db);
		
	}

}
