package com.eye.allseeingirc.database;

import java.util.ArrayList;

import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.bean.TalkListBean;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.webkit.WebChromeClient.CustomViewCallback;

public class LogDatabase {
	// ���̺� �̸�
	private static String table = "chat_log";
	// �÷�
	private static String col_id = "id";
	private static String col_chan = "chan";
	private static String col_mode = "mode";
	private static String col_nick = "nickname";
	private static String col_msg = "contents";
	private static String col_time = "time";

	String channelName;
	
	private int cursorPosition;

	Context context;
	SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Cursor cursor;

	public LogDatabase(Context context, String channelName) {
		this.channelName = channelName;
		this.context = context;
		helper = new AppDatabaseOpenHelper(context, "log.db", null, 1);
	}

	public LogDatabase(Context context) {
		this.context = context;
		helper = new AppDatabaseOpenHelper(context, "log.db", null, 1);
	}

	public void setBubbleList(ArrayList<BubbleBean> bubbleArrayList) {
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null, "chan=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToLast();

		int maxCount = 10;
		if (maxCount > cursor.getCount()) {
			maxCount = cursor.getCount();
		}

		for (int i = 0; i < maxCount; i++) {

			bubbleArrayList.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));

			cursor.moveToPrevious();
		}
		cursorPosition=cursor.getPosition();
		cursor.close();
		//database.close();

	}

	public int updateBubbleList(ArrayList<BubbleBean> bubbleArrayList) {
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null, "chan=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		int maxCount = 10;
		if (maxCount > cursorPosition+1) {
			maxCount = cursorPosition+1;
		}
		cursor.moveToPosition(cursorPosition);
		for (int i = 0; i < maxCount; i++) {
			bubbleArrayList.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));
			cursor.moveToPrevious();
		}
		cursorPosition=cursor.getPosition();
		cursor.close();
		//database.close();
		
		return maxCount;
	}
	
	public boolean searchBubbleList(ArrayList<BubbleBean> bubbleArrayList,String keyword) {
		ArrayList<BubbleBean> temp=new ArrayList<BubbleBean>();
		boolean flag=false;
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null, "chan=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToPosition(cursorPosition);
		for (int i = cursorPosition; i >0; i--) {
			temp.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));
			cursor.moveToPrevious();
			if(temp.get(0).getBubble().contains(keyword)){
				temp.get(0).searchtxt=keyword;
				bubbleArrayList.addAll(0, temp);
				cursorPosition=cursor.getPosition();
				flag=true;
				i=-1;
			}			
		}
		cursor.close();
		//database.close();
		
		return flag;
	}

	public void insertLog(int mode, String channelName, String nickName,
			String time, String bubble) {
		database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_chan, channelName);
		values.put(col_mode, mode);
		values.put(col_nick, nickName);
		values.put(col_msg, bubble);
		values.put(col_time, time);
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void insertLogfromUser(BubbleBean bubbleBean) {
		database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_chan, channelName);
		values.put(col_nick, bubbleBean.getNickName());
		values.put(col_mode, bubbleBean.getMode());
		values.put(col_msg, bubbleBean.getBubble());
		values.put(col_time, bubbleBean.getTime());
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void updateNickName(String arg1, String arg2) {
		// arg1 : �ٲٱ� �� �г���
		// arg2 : �ٲ� �� �г���
		ContentValues values = new ContentValues();
		values.put(col_nick, arg2);

		database = helper.getWritableDatabase();
		database.beginTransaction();
		database.update(table, values, "nickname=?", new String[] { arg1 });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void getLatestMsg(String chanName, TalkListBean dataBean) {
		int mode;
		database = helper.getReadableDatabase();
		database.beginTransaction();
		Cursor msgCursor = database.query(table, null, "chan=?",
				new String[] { chanName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if (msgCursor.getCount() > 0) {
			msgCursor.moveToLast();
			while(true){
				mode = msgCursor.getInt(msgCursor.getColumnIndex(col_mode));
				if (mode == 1 || mode == 2 || mode == 4 || mode == 6|| mode==7) {
					dataBean.setIndex(msgCursor.getInt(msgCursor
							.getColumnIndex(col_id)));
					//dataBean.setChanName(chanName);
					dataBean.setLatestMsg(msgCursor.getString(msgCursor
							.getColumnIndex(col_msg)));
					dataBean.setLatestTime(msgCursor.getString(msgCursor
							.getColumnIndex(col_time)));
					break;
				}
				if(!msgCursor.moveToPrevious()){
					break;
				}
			}
		} else {
			dataBean.setIndex(-1);
		}
		msgCursor.close();
		//database.close();
	}

	public void deleteLog() {
		database = helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, "chan=?", new String[] { channelName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	public void deleteAll(){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
}
