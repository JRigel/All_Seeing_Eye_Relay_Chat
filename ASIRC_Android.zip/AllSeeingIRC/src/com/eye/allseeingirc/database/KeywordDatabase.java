package com.eye.allseeingirc.database;

import java.util.ArrayList;

import com.eye.allseeingirc.bean.KeywordBean;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class KeywordDatabase {
	// ���̺� �̸�
	private static String table = "keyword_list";
	// �÷�
	private static String col_id = "id";
	private static String col_key = "keyword";
	
	SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Cursor cursor;

	public KeywordDatabase(Context context) {
		helper=new AppDatabaseOpenHelper(context, "log.db", null, 1);
	}
	
	public void setKeywordList(ArrayList<KeywordBean> arrayList){
		database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table, new String[]{col_key}, null, null, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		arrayList.clear();
		cursor.moveToFirst();
		for(int i=0;i<cursor.getCount();i++){
			arrayList.add(new KeywordBean(cursor.getString(cursor.getColumnIndex(col_key))));
			cursor.moveToNext();
		}
		cursor.close();
	}
	
	public boolean insertKeyword(String keyword){
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_key, keyword);
		database.beginTransaction();
		long i=database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
		if(i==-1){
			return false;
		}else{
			return true;
		}
	}
	public void deletetKeyword(String keyword){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, "keyword=?", new String[]{keyword});
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void deleteAll(){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public boolean checkKeyword(String keyword){
		database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table, new String[]{col_key}, "keyword=?", new String[]{keyword}, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if(cursor.getCount()>0){
			cursor.close();
			return true;
		}else{
			return false;
		}
	}

}
