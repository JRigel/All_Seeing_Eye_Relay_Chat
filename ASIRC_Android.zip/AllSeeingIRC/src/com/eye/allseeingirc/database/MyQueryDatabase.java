package com.eye.allseeingirc.database;

import java.util.ArrayList;
import java.util.Collections;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.utils.IndexDescCompare;

public class MyQueryDatabase {
	//���̺� �̸�
	private static String table="query_list";
	//�÷�
	private static String col_id="id";
	private static String col_nick="username";
	private static String col_alert="alert";
	private static String col_unread="unread";
	
	SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Cursor cursor;
	Context context;
	
	
	public MyQueryDatabase(Context context){
		helper=new AppDatabaseOpenHelper(context, "log.db", null, 1);
		this.context=context;
	}
	
	public int setTalkList(ArrayList<TalkListBean> list) {
		int unreadCnt = 0;
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_id, col_nick,
				col_alert,col_unread }, null, null,
				null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();

		String[] chanNames = new String[1000];

		list.clear();
		QueryLogDatabase log = new QueryLogDatabase(context);
		cursor.moveToFirst();
		for(int i=0;i<cursor.getCount();i++){
			TalkListBean newData = new TalkListBean();
			newData.setChanName(cursor.getString(cursor
					.getColumnIndex(col_nick)));
			log.getLatestMsg(cursor.getInt(cursor.getColumnIndex(col_id)),
					newData);
			if (cursor.getInt(cursor.getColumnIndex(col_alert)) == 1) {
				newData.setIsAlertable(true);
			} else {
				newData.setIsAlertable(false);
			}
			
			newData.setBadge(cursor.getInt(cursor.getColumnIndex(col_unread)));
			unreadCnt += newData.getBadge();
			list.add(newData);
			cursor.moveToNext();
		}

		Collections.sort(list, new IndexDescCompare());
		cursor.close();
		//database.close();

		return unreadCnt;
	}
	
	public int getQueryId(String username){
		int id;
		if(isNewQuery(username)){
			insertNewQuery(username);
		}
		database=helper.getReadableDatabase();
		cursor=database.query(table, new String[]{col_id}, "username=?", new String[]{username}, null, null, null);
		cursor.moveToLast();
		id=cursor.getInt(cursor.getColumnIndex(col_id));
		cursor.close();
		return id;
	}
	
	private void insertNewQuery(String username){
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_nick, username);
		values.put(col_alert, true);
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	private boolean isNewQuery(String username){
		database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table, new String[]{col_id}, "username=?", new String[]{username}, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if(cursor.getCount()>0){
			cursor.close();
			return false;
		}else{
			cursor.close();
			return true;
		}
	}
	
	public void updateUsername(String arg1,String arg2){
		ContentValues values = new ContentValues();
		values.put(col_nick, arg2);

		database = helper.getWritableDatabase();
		database.beginTransaction();
		database.update(table, values, "username=?", new String[] { arg1 });
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void deleteQuery(String username){
		int id=getQueryId(username);
		QueryLogDatabase queryLogDB=new QueryLogDatabase(context);
		queryLogDB.deleteQueryLog(id);
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, "username=?", new String[]{username});
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void setQueryUnreadZero(String username) {
		SQLiteDatabase database = helper.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(col_unread, 0);
		database.beginTransaction();
		database.update(table, values, "username=?", new String[] { username});
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	
	public void setQueryAlert(String username, boolean alert) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_alert, alert);
		database.beginTransaction();
		database.update(table, values, "username=?", new String[] { username });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	
	public boolean isAlertOn(String username) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_alert }, "username=?",
				new String[] { username }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if (cursor.getCount() > 0) {
			cursor.moveToFirst();
			if (cursor.getInt(cursor.getColumnIndex(col_alert)) == 1) {
				cursor.close();
				return true;
			} else {
				cursor.close();
				return false;
			}
		} else {
			cursor.close();
			return true;
		}
	}
	
	public void updateQueryUnread(String username) {
		int unread = getQueryUnread(username);
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_unread, unread + 1);
		database.beginTransaction();
		database.update(table, values, "username=?", new String[] { username });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	
	public int getQueryUnread(String username) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_unread },
				"username=?", new String[] { username }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToFirst();
		int unread=0;
		if(cursor.getCount()>0){
			unread=cursor.getInt(cursor.getColumnIndex(col_unread));
		}
		cursor.close();
		//database.close();
		return unread;
	}
	public void deleteAll(){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
}
