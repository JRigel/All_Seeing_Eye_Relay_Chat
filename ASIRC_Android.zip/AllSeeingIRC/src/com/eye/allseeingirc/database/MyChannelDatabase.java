package com.eye.allseeingirc.database;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import com.eye.allseeingirc.MainActivity;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.utils.IndexDescCompare;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.webkit.WebChromeClient.CustomViewCallback;

public class MyChannelDatabase {
	// ���̺� �̸�
	private static String table = "chat_list";
	// �÷�
	private static String col_id = "id";
	private static String col_chan = "channel";
	private static String col_topic = "topic";// �ش� ä�� ����
	private static String col_onoff = "onoff";// ���������� �ƴ��� ����
	private static String col_alert = "alert";// �˶� ������� �ƴ��� ����
	private static String col_unread = "unread";// ���� ���� �޽��� ��
	private static String col_count = "count";// �������� �ο� ��

	//SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Cursor cursor;
	Context context;

	public MyChannelDatabase(Context context) {
		helper = new AppDatabaseOpenHelper(context, "log.db", null, 1);
		this.context = context;
	}

	public int setTalkList(ArrayList<TalkListBean> list) {
		int unreadCnt = 0;
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_chan,
				col_alert, col_onoff, col_count, col_unread }, null, null,
				null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();

		String[] chanNames = new String[1000];

		list.clear();
		LogDatabase log = new LogDatabase(context);
		cursor.moveToFirst();
		for(int i=0;i<cursor.getCount();i++){
			TalkListBean newData = new TalkListBean();
			newData.setChanName(cursor.getString(cursor
					.getColumnIndex(col_chan)));
			log.getLatestMsg(cursor.getString(cursor.getColumnIndex(col_chan)),
					newData);
			if (cursor.getInt(cursor.getColumnIndex(col_alert)) == 1) {
				newData.setIsAlertable(true);
			} else {
				newData.setIsAlertable(false);
			}
			if (cursor.getInt(cursor.getColumnIndex(col_onoff)) == 1) {
				newData.setIsSubOn(true);
				newData.setCount(cursor.getInt(cursor.getColumnIndex(col_count)));
			} else {
				newData.setIsSubOn(false);
			}
			newData.setBadge(cursor.getInt(cursor.getColumnIndex(col_unread)));
			unreadCnt += newData.getBadge();
			list.add(newData);
			cursor.moveToNext();
		}

		Collections.sort(list, new IndexDescCompare());
		cursor.close();
		//database.close();

		return unreadCnt;
	}

	public boolean insertChannel(String chanName, boolean onoff, boolean alert,
			int count) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();

		// ä���� �ִ��� Ȯ��

		values.put(col_onoff, onoff);
		values.put(col_alert, alert);
		values.put(col_count, count);
		if (checkChannel(chanName)) {
			database.beginTransaction();
			database.update(table, values, "channel=?",
					new String[] { chanName });
			database.setTransactionSuccessful();
			database.endTransaction();
			//database.close();
			return true;

		} else {
			values.put(col_unread, 0);
			values.put(col_chan, chanName);
			database.beginTransaction();
			database.insert(table, null, values);
			database.setTransactionSuccessful();
			database.endTransaction();
			//database.close();

			return false;
		}
	}

	public void setChanOnOff(String chanName, boolean onoff) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_onoff, onoff);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[] { chanName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void updateChanOnOff(String[] chanName) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		database.beginTransaction();
		values.put(col_onoff, false);
		database.update(table, values, "onoff=?", new String[] { "1" });
		database.setTransactionSuccessful();
		database.endTransaction();
		if (chanName != null) {
			Cursor c;
			for (int i = 0; i < chanName.length; i += 2) {
				database.beginTransaction();
				c = database.query(table, new String[] { col_id }, "channel=?",
						new String[] { chanName[i] }, null, null, null);
				database.setTransactionSuccessful();
				database.endTransaction();
				if (c.getCount() > 0) {// ä���� ���� ���
					values.put(col_onoff, true);
					values.put(col_count, Integer.parseInt(chanName[i + 1]));
					database.beginTransaction();
					database.update(table, values, "channel=?",
							new String[] { chanName[i] });
					database.setTransactionSuccessful();
					database.endTransaction();
				} else {// ���� ���
					insertChannel(chanName[i], true, true,
							Integer.parseInt(chanName[i + 1]));
				}
				c.close();
			}
		}
		//database.close();
	}

	public void setChanAlert(String chanName, boolean alert) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_alert, alert);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[] { chanName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void updateChanUnread(String chanName, int unread) {
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_unread, unread + 1);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[] { chanName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void updateChanUnread(String chanName) {
		int unread = getChanUnread(chanName);
		SQLiteDatabase database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_unread, unread + 1);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[] { chanName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public int getChanUnread(String chanName) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_unread },
				"channel=?", new String[] { chanName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToFirst();
		int unread=0;
		if(cursor.getCount()>0){
			unread=cursor.getInt(cursor.getColumnIndex(col_unread));
		}
		cursor.close();
		//database.close();
		return unread;
	}

	public void setChanUnreadZero(String chanName) {
		SQLiteDatabase database = helper.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(col_unread, 0);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[] { chanName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}


	public void setTopic(String chanName,boolean isOpened) {
		SQLiteDatabase database = helper.getReadableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_topic, isOpened);
		database.beginTransaction();
		database.update(table, values, "channel=?", new String[]{chanName});
		database.setTransactionSuccessful();
		database.endTransaction();	
	}
	
	public boolean getTopic(String chanName) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table, new String[]{col_topic},"channel=?", new String[]{chanName}, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToFirst();
		if (cursor.getInt(cursor.getColumnIndex(col_topic)) == 1) {
			cursor.close();
			return true;
		} else {
			cursor.close();
			return false;
		}
	}

	public void deleteChannel(String channelName) {
		SQLiteDatabase database = helper.getWritableDatabase();
		database.beginTransaction();
		database.delete("chat_list", "channel=?", new String[] { channelName });
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
		LogDatabase log = new LogDatabase(context, channelName);
		log.deleteLog();
	}

	public boolean isSubOn(String channelName) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_onoff }, "channel=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToFirst();
		if (cursor.getInt(cursor.getColumnIndex(col_onoff)) == 1) {
			cursor.close();
			//database.close();
			return true;
		} else {
			cursor.close();
			//database.close();
			return false;
		}
	}

	public boolean isAlertOn(String channelName) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_alert }, "channel=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if (cursor.getCount() > 0) {
			cursor.moveToFirst();
			if (cursor.getInt(cursor.getColumnIndex(col_alert)) == 1) {
				cursor.close();
				return true;
			} else {
				cursor.close();
				return false;
			}
		} else {
			cursor.close();
			return true;
		}
	}

	public boolean checkChannel(String channelName) {
		SQLiteDatabase database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, new String[] { col_id }, "channel=?",
				new String[] { channelName }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if (cursor.getCount() > 0) {
			cursor.close();
			//database.close();
			return true;
		} else {
			cursor.close();
			//database.close();
			return false;
		}
	}
	
	private int getPeopleCount(String channelName){
		int count=0;
		SQLiteDatabase database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table, new String[]{col_count}, "channel=?", new String[]{channelName}, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToFirst();
		if(cursor.getCount()>0){
			count=cursor.getInt(cursor.getColumnIndex(col_count));
		}
		cursor.close();
		//database.close();
		return count;
	}

	public void updatePeopleIn(String channelName) {
		int count=getPeopleCount(channelName);
		SQLiteDatabase database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_count, count+1);
		database.beginTransaction();
		database.update(table, values, "channel=?",new String[]{channelName});
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}

	public void updatePeopleOut(String channelName) {
		int count=getPeopleCount(channelName);
		SQLiteDatabase database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_count, count-1);
		database.beginTransaction();
		database.update(table, values, "channel=?",new String[]{channelName});
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	public void deleteAll(){
		SQLiteDatabase database=helper.getWritableDatabase();
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
}
