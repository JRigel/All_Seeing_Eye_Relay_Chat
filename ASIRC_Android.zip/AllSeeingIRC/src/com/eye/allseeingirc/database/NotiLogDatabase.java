package com.eye.allseeingirc.database;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.eye.allseeingirc.adapter.NotiLogListAdapter;
import com.eye.allseeingirc.bean.NotificationBean;

public class NotiLogDatabase {
	//���̺� �̸�
	private static String table="noti_log";
	//�÷�
	private static String col_id="id";
	private static String col_type="type";
	private static String col_chan="chan";
	private static String col_nick="nickname";
	private static String col_msg="contents";
	private static String col_time="time";
	private static String col_check="ischecked";
	/*
	 * mode
	 * 1:����޽���
	 * 2:�˸�/����
	 * 3:�ʴ�
	 * 4:�Ӹ�ȣ��
	 * 5:ȣ�� or ����
	 * 6:��ȭ�� ����
	 * 7:��Ƽ��ChanServ,NickServe
	 */
	SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Context context;
	
	public NotiLogDatabase(Context context){
		this.context=context;
		helper=new AppDatabaseOpenHelper(context, "log.db", null, 1);
	}
	
	public int setNotiLog(ArrayList<NotificationBean> notiArrayList){
		//��Ƽ�����̼� �����ϸ� ����� �κ�
		Cursor cursor;
		int nonChecked=0;
		database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table,null,null,null,null,null,null);
		database.setTransactionSuccessful();
		database.endTransaction();
		notiArrayList.clear();
		while(cursor.moveToNext()){
			NotificationBean data=new NotificationBean();
			data.setType(cursor.getInt(cursor.getColumnIndex(col_type)));
			data.setTimestamp(cursor.getString(cursor.getColumnIndex(col_time)));
			data.setChan(cursor.getString(cursor.getColumnIndex(col_chan)));
			if(cursor.getInt(cursor.getColumnIndex(col_check))==1){
				data.setIsChecked(true);
			}else{
				data.setIsChecked(false);
				nonChecked++;
			}
			data.setMsg(cursor.getString(cursor.getColumnIndex(col_msg)));
			data.setNick(cursor.getString(cursor.getColumnIndex(col_nick)));
			
			
			notiArrayList.add(0, data);
		}
		cursor.close();
		return nonChecked;
	}
	
	public int setNotiLogTabSelected(ArrayList<NotificationBean> notiArrayList){
		//��Ƽ�����̼� �����ϸ� ����� �κ�
		Cursor cursor;
		int nonChecked=0;
		database=helper.getReadableDatabase();
		database.beginTransaction();
		cursor=database.query(table,null,null,null,null,null,null);
		database.setTransactionSuccessful();
		database.endTransaction();
		notiArrayList.clear();
		while(cursor.moveToNext()){
			NotificationBean data=new NotificationBean();
			data.setType(cursor.getInt(cursor.getColumnIndex(col_type)));
			data.setTimestamp(cursor.getString(cursor.getColumnIndex(col_time)));
			data.setChan(cursor.getString(cursor.getColumnIndex(col_chan)));
			if(cursor.getInt(cursor.getColumnIndex(col_check))==1){
				data.setIsChecked(true);
			}else{
				data.setIsChecked(false);
				nonChecked++;
			}
			data.setMsg(cursor.getString(cursor.getColumnIndex(col_msg)));
			data.setNick(cursor.getString(cursor.getColumnIndex(col_nick)));
			
			setNotiRead(cursor.getInt(cursor.getColumnIndex(col_id)));
			
			notiArrayList.add(0, data);
		}
		cursor.close();
		return nonChecked;
	}
	
	public void insertNewNotiLog(int type,String chan,String nick,String msg,String time){
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_chan, chan);
		values.put(col_check, false);
		values.put(col_msg, msg);
		values.put(col_nick, nick);
		values.put(col_time, time);
		values.put(col_type, type);
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void deleteAllLog(){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	private void setNotiRead(int id){
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_check, true);
		database.beginTransaction();
		database.update(table, values, "id=?", new String[]{id+""});
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void setAllNotiRead(){
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_check, true);
		database.beginTransaction();
		database.update(table, values, "ischecked=?", new String[]{"0"});
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void deleteAll(){
		SQLiteDatabase database=helper.getWritableDatabase();
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
}