package com.eye.allseeingirc.database;

import java.util.ArrayList;

import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.bean.TalkListBean;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class QueryLogDatabase {
	//���̺� �̸�
	private static String table="query_log";
	//�÷�
	private static String col_id="id";
	private static String col_query="queryid";
	private static String col_mode="mode";
	private static String col_nick="nickname";
	private static String col_msg="contents";
	private static String col_time="time";
	
	private int cursorPosition;
	
	SQLiteDatabase database;
	AppDatabaseOpenHelper helper;
	Cursor cursor;
	
	Context context;
	
	public QueryLogDatabase(Context context){
		helper=new AppDatabaseOpenHelper(context, "log.db", null, 1);
		this.context=context;
	}
	
	public void setBubbleList(int queryId,ArrayList<BubbleBean> bubbleArrayList) {
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null, "queryId=?",
				new String[] { queryId+"" }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToLast();

		int maxCount = 10;
		if (maxCount > cursor.getCount()) {
			maxCount = cursor.getCount();
		}

		for (int i = 0; i < maxCount; i++) {

			bubbleArrayList.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));

			cursor.moveToPrevious();
		}
		cursorPosition=cursor.getPosition();
		cursor.close();
		//database.close();

	}

	public int updateBubbleList(int queryId,ArrayList<BubbleBean> bubbleArrayList) {
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null, "queryId=?",
				new String[] { queryId+"" }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		int maxCount = 10;
		if (maxCount > cursorPosition+1) {
			maxCount = cursorPosition+1;
		}
		cursor.moveToPosition(cursorPosition);
		for (int i = 0; i < maxCount; i++) {
			bubbleArrayList.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));
			cursor.moveToPrevious();
		}
		cursorPosition=cursor.getPosition();
		cursor.close();
		//database.close();
		
		return maxCount;
	}
	
	public void insertQueryLogDatabase(String username,int mode, String msg,String time){
		MyQueryDatabase queryDB=new MyQueryDatabase(context);
		int queryId=queryDB.getQueryId(username);
		database=helper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put(col_mode, mode);
		values.put(col_msg, msg);
		values.put(col_nick, username);
		values.put(col_query, queryId);
		values.put(col_time, time);
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();				
	}
	
	public void insertQueryLogfromUser(int queryId,BubbleBean bubbleBean) {
		database = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(col_query, queryId);
		values.put(col_nick, bubbleBean.getNickName());
		values.put(col_mode, bubbleBean.getMode());
		values.put(col_msg, bubbleBean.getBubble());
		values.put(col_time, bubbleBean.getTime());
		database.beginTransaction();
		database.insert(table, null, values);
		database.setTransactionSuccessful();
		database.endTransaction();
		//database.close();
	}
	public void deleteQueryLog(int id){
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, "queryid=?", new String[]{id+""});
		database.setTransactionSuccessful();
		database.endTransaction();
	}
	
	public void getLatestMsg(int queryId, TalkListBean data){
		int mode;
		database = helper.getReadableDatabase();
		database.beginTransaction();
		Cursor msgCursor = database.query(table, null, "queryid=?",
				new String[] { queryId+"" }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		if (msgCursor.getCount() > 0) {
			msgCursor.moveToLast();
			while(true){
				mode = msgCursor.getInt(msgCursor.getColumnIndex(col_mode));
				if (mode == 1 || mode == 2 || mode == 4 || mode == 6|| mode==7) {
					data.setIndex(msgCursor.getInt(msgCursor
							.getColumnIndex(col_id)));
					//dataBean.setChanName(chanName);
					data.setLatestMsg(msgCursor.getString(msgCursor
							.getColumnIndex(col_msg)));
					data.setLatestTime(msgCursor.getString(msgCursor
							.getColumnIndex(col_time)));
					break;
				}
				if(!msgCursor.moveToPrevious()){
					break;
				}
			}
		} else {
			data.setIndex(-1);
		}
		msgCursor.close();
	}
	
	public boolean searchBubbleList(int queryId,ArrayList<BubbleBean> bubbleArrayList,String keyword) {
		ArrayList<BubbleBean> temp=new ArrayList<BubbleBean>();
		boolean flag=false;
		database = helper.getReadableDatabase();
		database.beginTransaction();
		cursor = database.query(table, null,  "queryid=?",
				new String[] { queryId+"" }, null, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
		cursor.moveToPosition(cursorPosition);
		for (int i = cursorPosition; i >0; i--) {
			temp.add(
					0,
					new BubbleBean(cursor.getInt(cursor
							.getColumnIndex(col_mode)), cursor.getString(cursor
							.getColumnIndex(col_nick)), cursor.getString(cursor
							.getColumnIndex(col_time)), cursor.getString(cursor
							.getColumnIndex(col_msg))));
			cursor.moveToPrevious();
			if(temp.get(0).getBubble().contains(keyword)){
				temp.get(0).searchtxt=keyword;
				bubbleArrayList.addAll(0, temp);
				cursorPosition=cursor.getPosition();
				flag=true;
				i=-1;
			}			
		}
		cursor.close();
		//database.close();
		
		return flag;
	}
	
	public void deleteAll(){
		SQLiteDatabase database=helper.getWritableDatabase();
		database=helper.getWritableDatabase();
		database.beginTransaction();
		database.delete(table, null, null);
		database.setTransactionSuccessful();
		database.endTransaction();
	}
}
