package com.eye.allseeingirc;

import android.app.Activity;
import android.content.Intent;
import android.content.ReceiverCallNotAllowedException;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.eye.allseeingirc.network.CentralServerNetwork;
import com.google.android.gcm.GCMRegistrar;

public class UserAuthActivity extends Activity{
	AllSeiingIRCApplication application;
	public CentralServerNetwork userAuth;
	
	public TextView authNum;
	public ProgressBar progressBar;
	public TextView messageTxt;
	public ProgressBar loadingLog;
	public TextView loadingText;
	ReceiveRegId receiver;
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_userauth);
		
		authNum=(TextView)findViewById(R.id.textview_authnum);
		progressBar=(ProgressBar)findViewById(R.id.loading_authnum);
		messageTxt=(TextView)findViewById(R.id.textView_mssage);
		
		loadingLog=(ProgressBar) findViewById(R.id.loading_bar);
		loadingLog.getProgressDrawable().setColorFilter(Color.GRAY, Mode.SRC_IN);
		
		loadingText=(TextView)findViewById(R.id.tv_update);
		
		userAuth=new CentralServerNetwork(this, handler);
		
		receiver=new ReceiveRegId();
		receiver.setDaemon(true);
		receiver.start();
		
	}
	
	public Handler handler=new Handler(){
		int totalMsg=0;
		int logCount=0;
		public void handleMessage(Message message){
			switch (message.what) {
			case 1:
				Toast.makeText(UserAuthActivity.this, "���� ���� ����", Toast.LENGTH_SHORT).show();
				android.os.Process.killProcess(android.os.Process.myPid());
				userAuth.setThreadStop();
				finish();
				break;
			case 0:
				if(message.obj!=null){
				progressBar.setAlpha(0);
				authNum.setText(message.obj.toString());
				messageTxt.setText("�� ������ȣ 4�ڸ��� PC�� �Է����ּ���.");
				
				}
				break;
			case 3:
				SharedPreferences pref=getSharedPreferences("pref",MODE_PRIVATE);
				SharedPreferences.Editor editor=pref.edit();
				editor.putString("ip", message.obj.toString().replace(" ",""));
				editor.commit();
				userAuth.setThreadStop();
				application=(AllSeiingIRCApplication)getApplicationContext();
				application.setRemoteClient(pref.getString("ip", ""), handler, null,true);
				
				
				break;
				
			case 4:
				receiver.interrupt();
				receiver=null;
				userAuth.userAuthenticator(message.obj.toString());
				
				break;
				
			case 100:
				totalMsg=message.arg1;
				loadingLog.setProgress(logCount);
				loadingLog.setMax(totalMsg);
				messageTxt.setVisibility(View.GONE);
				loadingLog.setVisibility(View.VISIBLE);
				loadingText.setVisibility(View.VISIBLE);
				break;
				
			case 5:
				if (message.arg1 == 8) {
					Intent main=new Intent(UserAuthActivity.this,MainActivity.class);
					startActivity(main);
					application.remoteClientNetwork.isSplash = false;
					finish(); // ��Ƽ��Ƽ ����

				} else {
					logCount++;
					loadingLog.setProgress(logCount);
				}
				break;
				
				
			default:
				break;
			}
		}
	};
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		userAuth.setThreadStop();
	};
	
	class ReceiveRegId extends Thread{
		public void run(){
			String regId="";
			while("".equals(regId)){
				regId=GCMRegistrar.getRegistrationId(UserAuthActivity.this);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			Log.e("regId", regId);
			Message msg=new Message();
			msg.what=4;
			msg.obj=regId;
			handler.sendMessage(msg);
			
			
		}
	}
}
