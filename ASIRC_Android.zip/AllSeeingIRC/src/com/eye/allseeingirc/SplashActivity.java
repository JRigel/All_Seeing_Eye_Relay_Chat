package com.eye.allseeingirc;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gcm.GCMRegistrar;

public class SplashActivity extends Activity {
	Intent nextActivity;
	AllSeiingIRCApplication application;
	
	public ProgressBar loadingLog;
	public TextView loadingText;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		application=(AllSeiingIRCApplication) getApplicationContext();
		NotificationManager nm = 
                (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
         
        // ��ϵ� notification �� ���� �Ѵ�.
        nm.cancel(0);
        
        SharedPreferences pref = getSharedPreferences("pref",
				MODE_PRIVATE);
		SharedPreferences.Editor editor=pref.edit();
		//���� �����ϰ� �׽�Ʈ �ϱ����� �κ���..
		editor.putInt("msgcnt", 0);
		editor.commit();
		//���� �Ϸ��� ������� ����
		
		loadingLog=(ProgressBar) findViewById(R.id.loading_bar);
		loadingLog.getProgressDrawable().setColorFilter(Color.LTGRAY, Mode.SRC_IN);
		
		loadingText=(TextView)findViewById(R.id.tv_update);
		
		if(!pref.getBoolean("first", false)){
			editor.putBoolean("first", true);
			editor.putBoolean("back", true);
			editor.putInt("backres", R.drawable.background_5);
			editor.commit();
		}
		
		if (pref.getString("ip", null) == null) {
			nextActivity=new Intent(this,UserAuthActivity.class);
			
			handler.sendEmptyMessageDelayed(1, 1000);
		} else {
			nextActivity=new Intent(this,MainActivity.class);
			Intent temp=getIntent();
			nextActivity.putExtra("noti", temp.getIntExtra("noti", 0));
			nextActivity.putExtra("name", temp.getStringExtra("name"));
			application
			.setRemoteClient(pref.getString("ip", ""), handler, null,true);
		}
		
	}

	private void registGCM() {
		GCMRegistrar.checkDevice(this);
		GCMRegistrar.checkManifest(this);
		final String regId = GCMRegistrar.getRegistrationId(this);

		if ("".equals(regId)) // ���� ���̵忡�� regId.equals("")�� �Ǿ� �ִµ� Exception��
								// ���ϱ� ���� ����
			GCMRegistrar.register(this, GCMIntentService.SEND_ID);
	}

	Handler handler = new Handler() {
		int totalMsg=0;
		int logCount=0;
		@Override
		public void handleMessage(Message msg) {
			
			switch (msg.what) {
			case 0:
				Log.e("Splash", "���� ��");
				break;

			case 1:
				Log.e("Splash", "���� �ȵ�");
				startActivity(nextActivity);
				registGCM();
				finish();
				break;

			case 100:
				totalMsg=msg.arg1;
				loadingLog.setProgress(logCount);
				loadingLog.setMax(totalMsg);
				loadingLog.setVisibility(View.VISIBLE);
				loadingText.setVisibility(View.VISIBLE);
				break;
				
			case 5:
				if (msg.arg1 == 8) {
					startActivity(nextActivity);
					application.remoteClientNetwork.isSplash = false;
					registGCM();
					finish(); // ��Ƽ��Ƽ ����

				} else {
					logCount++;
					loadingLog.setProgress(logCount);
				}
				break;
			case 200:
				
				break;
			default:
				break;
			}
		}
		
	};

	@Override
	protected void onDestroy() {
		GCMRegistrar.onDestroy(this);
		super.onDestroy();
	}
}
