package com.eye.allseeingirc;

import android.app.ActionBar;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class TabUtil {
	TextView count;
	
	public TabUtil(){
		
	}
	
	public View renderTabView(Context context,int iconId,int badgeNumber) {
		FrameLayout view = (FrameLayout) LayoutInflater.from(context).inflate(
				R.layout.tab_badge, null);
		view.setLayoutParams(new ViewGroup.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));
		ImageView icon=(ImageView) view.findViewById(R.id.tab_icon);
		icon.setImageResource(iconId);
		count=(TextView)view.findViewById(R.id.tab_badge);
		updateTabBadge(badgeNumber);
		return view;
	}

	private void updateTabBadge(ActionBar.Tab tab, int badgeNumber) {
		updateTabBadge(badgeNumber);
	}

	public void updateTabBadge(int badgeNumber) {
		if (badgeNumber > 0) {
			if(badgeNumber>300){
				count.setText("300+");
			}else{
				count.setText(Integer.toString(badgeNumber));
				
			}
			count.setVisibility(View.VISIBLE);
		} else {
			count.setVisibility(View.GONE);
		}
	}
	
}
