package com.eye.allseeingirc.listener;

import org.json.JSONException;
import org.json.JSONObject;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

public class InviteButtonClick implements OnClickListener{
	String chanName;
	Context context;
	AlertDialog inviteUserDialog;
	
	public InviteButtonClick(Context context,String chanName) {
		this.chanName=chanName;
		this.context=context;
	}
	@Override
	public void onClick(View v) {
		inviteUserDialog=createDialog();
		inviteUserDialog.show();
	}

	public void setDismiss(AlertDialog dialog){
		if (dialog != null && dialog.isShowing())
			dialog.dismiss();
	}
	
	private AlertDialog createDialog() {
		final View innerView=((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_invite,null);
		AlertDialog.Builder ab = new AlertDialog.Builder(context);
		ab.setTitle("�ʴ��ϱ�");
		ab.setView(innerView);

		final EditText etNick = (EditText) innerView
				.findViewById(R.id.edit_user);

		ab.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (!etNick.getText().toString().trim().equals("")) {
					
					AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
							.getApplicationContext();
					if (application.remoteClientNetwork.isSocketConnected) {
						JSONObject jsonObject = new JSONObject();
						try {
							jsonObject.put("message", "/invite " + etNick.getText().toString()+" "+chanName);
							application.remoteClientNetwork
									.sendMessage(jsonObject.toString());
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}else{
						Toast.makeText(context, "��Ʈ��ũ ������ Ȯ�����ּ���.",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(context, "�г����� ����ֽ��ϴ�.",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		

		ab.setNegativeButton("���", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				setDismiss(inviteUserDialog);
			}
		});

		return ab.create();
	}

}
