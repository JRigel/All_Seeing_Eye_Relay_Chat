package com.eye.allseeingirc.listener;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.SplashActivity;
import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.database.QueryLogDatabase;

public class DelDataButtonClick implements OnClickListener {
	Context context;
	Handler handler;

	public DelDataButtonClick(Context context, Handler handler) {
		this.context = context;
		this.handler = handler;
	}

	@Override
	public void onClick(View v) {
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(context);
		dialBuilderDel.setTitle("������ ����");
		dialBuilderDel.setMessage("���� ������ ������ ��� �����Ͱ� ���� �˴ϴ�.");
		dialBuilderDel.setPositiveButton("��",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						SharedPreferences pref = context.getSharedPreferences(
								"pref", Context.MODE_PRIVATE);
						SharedPreferences.Editor editor = pref.edit();
						editor.remove("first");
						editor.remove("back");
						editor.remove("backres");
						editor.remove("backuri");
						editor.commit();
						LogDatabase logDB = new LogDatabase(context);
						NotiLogDatabase notiDB = new NotiLogDatabase(context);
						QueryLogDatabase queryDB = new QueryLogDatabase(context);
						MyChannelDatabase myChanDB = new MyChannelDatabase(
								context);
						MyQueryDatabase myQueryDB = new MyQueryDatabase(context);
						logDB.deleteAll();
						notiDB.deleteAll();
						queryDB.deleteAll();
						myChanDB.deleteAll();
						myQueryDB.deleteAll();
						AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
								.getApplicationContext();
						if (application.remoteClientNetwork.socket
								.isConnected()) {

							JSONObject settingMsg = new JSONObject();
							try {
								settingMsg.put("message", "/chan_list");
								application.remoteClientNetwork.sendMessage(settingMsg.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
							try {
								Thread.sleep(500);
								settingMsg.put("message", "/my_nick");
								application.remoteClientNetwork.sendMessage(settingMsg.toString());
							} catch (InterruptedException e) {
								e.printStackTrace();
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
						handler.sendEmptyMessage(3);

					}

				});
		dialBuilderDel.setNegativeButton("�ƴϿ�",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					}
				});
		dialBuilderDel.show();
	}

}
