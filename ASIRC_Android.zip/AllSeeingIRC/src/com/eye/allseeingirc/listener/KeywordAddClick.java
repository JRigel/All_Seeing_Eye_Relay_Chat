package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.adapter.KeywordListAdapter;
import com.eye.allseeingirc.bean.KeywordBean;
import com.eye.allseeingirc.database.KeywordDatabase;

public class KeywordAddClick implements OnClickListener {
	EditText etKeyword;
	Context context;
	
	public KeywordAddClick(Context context,EditText etKeyword) {
		this.context=context;
		this.etKeyword=etKeyword;
	}

	@Override
	public void onClick(View v) {
		AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
				.getApplicationContext();
		if (application.remoteClientNetwork.socket
				.isConnected()) {// ��Ʈ��ũ ����Ǿ����� ��
			if (!etKeyword.getText().toString()
					.replace(" ", "").equals("")) {
					KeywordDatabase keyDB=new KeywordDatabase(context);
					if(keyDB.checkKeyword(etKeyword.getText().toString())){
						Toast.makeText(context, "�̹� �߰��� Ű�����Դϴ�.",
								Toast.LENGTH_SHORT).show();
					}else{
						JSONObject jsonObject = new JSONObject();
						try {
							jsonObject.put("message", "/hg_add "
									+ etKeyword.getText()
										.toString());
							application.remoteClientNetwork
							.sendMessage(jsonObject
										.toString());
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				
			} else {
				Toast.makeText(context, "�� �ؽ�Ʈ�Դϴ�.",
						Toast.LENGTH_SHORT).show();
			}
		} else {
			Toast.makeText(context, "��Ʈ��ũ�� ����Ǿ����� �ʽ��ϴ�.",
					Toast.LENGTH_SHORT).show();
		}

		etKeyword.setText("");
	}
	

}
