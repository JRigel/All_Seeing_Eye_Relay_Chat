package com.eye.allseeingirc.listener;

import android.view.View;
import android.view.View.OnLongClickListener;

public class BubbleLongClick implements OnLongClickListener{

	
	public BubbleLongClick(){
		
	}
	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		return false;
	}

}
