package com.eye.allseeingirc.listener;

import org.json.JSONException;
import org.json.JSONObject;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.MainActivity;
import com.eye.allseeingirc.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class UserNicknameClick implements OnClickListener{
	Context context;
	AlertDialog changeNickDialog;
	
	public UserNicknameClick(Context context) {
		this.context=context;
	}

	@Override
	public void onClick(View v) {
		changeNickDialog=createDialog();
		changeNickDialog.show();
	}

	public void setDismiss(AlertDialog dialog){
		if (dialog != null && dialog.isShowing())
			dialog.dismiss();
	}
	
	private AlertDialog createDialog() {
		final View innerView=((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_changenick,null);
		AlertDialog.Builder ab = new AlertDialog.Builder(context);
		ab.setTitle("�� �г��� ����");
		ab.setView(innerView);

		final EditText myNick = (EditText) innerView
				.findViewById(R.id.edit_myNick);

		ab.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				if (!myNick.getText().toString().trim().equals("")) {
					
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/nick "+ myNick.getText().toString());
						AllSeiingIRCApplication application=(AllSeiingIRCApplication) context.getApplicationContext();
						application.remoteClientNetwork.sendMessage(jsonObject
								.toString());
					} catch (JSONException e) {
						e.printStackTrace();
					}
				} else {
					Toast.makeText(context, "�г����� ����ֽ��ϴ�.",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		

		ab.setNegativeButton("���", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				setDismiss(changeNickDialog);
			}
		});

		return ab.create();
	}
	
	

}
