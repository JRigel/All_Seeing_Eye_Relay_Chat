package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;

import com.eye.allseeingirc.adapter.QueryListAdapter;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.MyQueryDatabase;

public class QueryItemLongClick implements OnItemLongClickListener{
	Context context;
	QueryListAdapter adapter;
	ArrayList<TalkListBean> list;
	Handler handler;
	
	public QueryItemLongClick(Context context,QueryListAdapter adapter,ArrayList<TalkListBean> list,Handler handler) {
		this.context=context;
		this.adapter=adapter;
		this.list=list;
		this.handler=handler;
	}
	
	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			final int position, long id) {
		final String userName = list.get(position).getChanName();
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(context);
		dialBuilderDel.setTitle(userName);
		String[] items = { "��ȭ �˸� �ѱ�", "�ϴ��� ��ȭ ����" };

		if (list.get(position).getIsAlertable()) {
			items[0] = "��ȭ �˸� ����";
		}

		final MyQueryDatabase db = new MyQueryDatabase(context);
		dialBuilderDel.setItems(items, new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0://�˸�
					list.get(position).setIsAlertable(
							!list.get(position).getIsAlertable());
					db.setQueryAlert(userName, list.get(position)
							.getIsAlertable());
					adapter.notifyDataSetChanged();
					break;
				default:
					if(list.get(position).getBadge()>0){
						Message msg=new Message();
						msg.what=3;
						msg.arg1=list.get(position).getBadge();
						handler.sendMessage(msg);
					}
					list.remove(position);
					db.deleteQuery(userName);
					adapter.notifyDataSetChanged();
					break;
				}
			}
		});
		
		dialBuilderDel.show();
		return true;
	}

}
