package com.eye.allseeingirc.listener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.adapter.BubbleListAdapter;
import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.database.LogDatabase;

public class SendButtonClick implements OnClickListener {
	Context context;
	EditText message;
	Handler handler;

	boolean cmdMode;

	public SendButtonClick(Context context,EditText message, Handler handler) {
		this.context = context;
		this.message = message;
		this.handler = handler;
	}

	@Override
	public void onClick(View v) {
		AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
				.getApplicationContext();
		if (application.remoteClientNetwork.isSocketConnected) {
			if (!message.getText().toString().trim().equals("")) {// �޽����� �������θ� �̷����°�
				Message handleMsg=new Message();
				handleMsg.what=0;
				handleMsg.obj=message.getText().toString();
				handler.sendMessage(handleMsg);
				message.setText(null);

			}
		} else {
			handler.sendEmptyMessage(2);
			message.setText(null);
		}
	}

}
