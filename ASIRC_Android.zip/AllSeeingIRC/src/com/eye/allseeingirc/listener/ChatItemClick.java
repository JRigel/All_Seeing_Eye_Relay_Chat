/*
 * << ChatItemClick >>
 * - ��ȭ��Ͽ��� ����Ʈ �������� Ŭ������ �� �����ϴ� ������
 */

package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import com.eye.allseeingirc.ChatActivity;
import com.eye.allseeingirc.MainActivity;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.MyChannelDatabase;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class ChatItemClick implements OnItemClickListener{
	Context context;
	ArrayList<TalkListBean> list;
	
	public ChatItemClick(Context context,ArrayList<TalkListBean> list){
		this.context=context;
		this.list=list;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Intent chatIntent=new Intent(context,ChatActivity.class);
		chatIntent.putExtra("listItem", list.get(position).getChanName());
		context.startActivity(chatIntent); 
	}

}
