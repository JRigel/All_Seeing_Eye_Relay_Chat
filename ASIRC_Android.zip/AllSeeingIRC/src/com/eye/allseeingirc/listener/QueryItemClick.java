package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import com.eye.allseeingirc.ChatActivity;
import com.eye.allseeingirc.QueryActivity;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

public class QueryItemClick implements OnItemClickListener{
	Context context;
	ArrayList<TalkListBean> list;
	
	public QueryItemClick(Context context, ArrayList<TalkListBean> list) {
		this.context=context;
		this.list=list;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		String username=list.get(position).getChanName();
		int queryId;
		Intent queryIntent=new Intent(context,QueryActivity.class);
		MyQueryDatabase db=new MyQueryDatabase(context);
		queryId=db.getQueryId(username);
		queryIntent.putExtra("queryId", queryId);
		queryIntent.putExtra("listItem", username);
		context.startActivity(queryIntent); 
	}

}
