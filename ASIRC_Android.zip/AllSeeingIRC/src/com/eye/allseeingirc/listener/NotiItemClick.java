package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.bean.NotificationBean;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.MyChannelDatabase;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;


public class NotiItemClick implements OnItemClickListener{
	Context context;
	ArrayList<NotificationBean> list;

	public NotiItemClick(Context context, ArrayList<NotificationBean> list) {
		this.context = context;
		this.list = list;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		if (list.get(position).getType() == 3) {
			final String chanName = list.get(position).getChan();
			AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(
					context);
			dialBuilderDel.setTitle("�ʴ�");
			dialBuilderDel.setMessage(chanName
					+ "�� �����Ͻðڽ��ϱ�?");
			dialBuilderDel.setPositiveButton("��", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
							.getApplicationContext();
					if (application.remoteClientNetwork.isSocketConnected) {
						JSONObject jsonObject = new JSONObject();
						try {
							jsonObject.put("message", "/join " + chanName);
							application.remoteClientNetwork
									.sendMessage(jsonObject.toString());
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				}
			});
			dialBuilderDel.setNegativeButton("�ƴϿ�", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				}
			});

			dialBuilderDel.show();
		}
	}

}
