package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemLongClickListener;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.bean.KeywordBean;

public class KeywordItemLongClick implements OnItemLongClickListener {
	Context context;
	ArrayList<KeywordBean> keywordList;

	public KeywordItemLongClick(Context context,
			ArrayList<KeywordBean> keywordList) {
		this.context = context;
		this.keywordList = keywordList;
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			final int position, long id) {
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(
				context);
		dialBuilderDel.setTitle("Ű���� ����");
		dialBuilderDel.setMessage("Ű���� \'"+keywordList.get(position).keyword+"\'�� �����Ͻðڽ��ϱ�?");
		dialBuilderDel.setPositiveButton("��", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
						.getApplicationContext();
				if (application.remoteClientNetwork.isSocketConnected) {
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/hg_del "
								+ keywordList.get(position).keyword);
						application.remoteClientNetwork
								.sendMessage(jsonObject.toString());
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}else {
			Toast.makeText(context, "��Ʈ��ũ�� ����Ǿ����� �ʽ��ϴ�.", Toast.LENGTH_SHORT)
					.show();
		}
			}
		});
		dialBuilderDel.setNegativeButton("�ƴϿ�", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}
		});

		dialBuilderDel.show();
		
		return false;
	}

}
