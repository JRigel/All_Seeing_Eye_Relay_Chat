package com.eye.allseeingirc.listener;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.SplashActivity;
import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.database.QueryLogDatabase;

public class AuthDelButtonClick implements View.OnClickListener{
	Context context;
	Handler handler;
	
	public AuthDelButtonClick(Context context,Handler handler) {
		this.context=context;
		this.handler=handler;
	}
	@Override
	public void onClick(View v) {
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(
				context);
		dialBuilderDel.setTitle("��������");
		dialBuilderDel.setMessage("PC���� ������ �����ϰ�, ��� ����� ����ðڽ��ϱ�?");
		dialBuilderDel.setPositiveButton("��", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
						.getApplicationContext();
				if (application.remoteClientNetwork.isSocketConnected) {
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/smart_auth_cancel_phone");
						application.remoteClientNetwork
						.sendMessage(jsonObject.toString());
						SharedPreferences pref = context.getSharedPreferences("pref",
								Context.MODE_PRIVATE);
						SharedPreferences.Editor editor = pref.edit();
						editor.remove("ip");
						editor.remove("first");
						editor.remove("back");
						editor.remove("backres");
						editor.remove("backuri");
						editor.remove("mynick");
						editor.commit();
						KeywordDatabase keywordDB = new KeywordDatabase(context);
						LogDatabase logDB = new LogDatabase(context);
						NotiLogDatabase notiDB = new NotiLogDatabase(context);
						QueryLogDatabase queryDB = new QueryLogDatabase(context);
						MyChannelDatabase myChanDB=new MyChannelDatabase(context);
						MyQueryDatabase myQueryDB=new MyQueryDatabase(context);
						keywordDB.deleteAll();
						logDB.deleteAll();
						notiDB.deleteAll();
						queryDB.deleteAll();
						myChanDB.deleteAll();
						myQueryDB.deleteAll();
						Intent mIntent = new Intent(context, SplashActivity.class);
						context.startActivity(mIntent);
						handler.sendEmptyMessage(1);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}else{
					Toast.makeText(context, "��Ʈ��ũ ������ Ȯ�����ּ���.",
							Toast.LENGTH_SHORT).show();
				}
				
			}

		});
		dialBuilderDel.setNegativeButton("�ƴϿ�", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}
		});
		dialBuilderDel.show();
		
	}

}
