package com.eye.allseeingirc.listener;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.SplashActivity;
import com.eye.allseeingirc.database.KeywordDatabase;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.database.NotiLogDatabase;
import com.eye.allseeingirc.database.QueryLogDatabase;

public class DelAllKeywordButtonClick implements OnClickListener {
	Context context;

	public DelAllKeywordButtonClick(Context context) {
		this.context = context;
	}

	@Override
	public void onClick(View v) {
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(context);
		dialBuilderDel.setTitle("Ű���� ����");
		dialBuilderDel.setMessage("��� Ű���带 �����Ͻðڽ��ϱ�?");
		dialBuilderDel.setPositiveButton("��",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						
						AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
								.getApplicationContext();
						if (application.remoteClientNetwork.socket
								.isConnected()) {

							JSONObject settingMsg = new JSONObject();
							try {
								settingMsg.put("message", "/hg_clear");
								application.remoteClientNetwork.sendMessage(settingMsg.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}

					}

				});
		dialBuilderDel.setNegativeButton("�ƴϿ�",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					}
				});
		dialBuilderDel.show();
	}

}
