package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.adapter.NotiLogListAdapter;
import com.eye.allseeingirc.bean.NotificationBean;
import com.eye.allseeingirc.database.NotiLogDatabase;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;

public class NotiDelClick implements OnClickListener{
	Context context;
	ArrayList<NotificationBean> notiList;
	ArrayList<NotificationBean> allNoti;
	NotiLogListAdapter notiAdapter;
	
	
	public NotiDelClick(Context context,ArrayList<NotificationBean> notiList,ArrayList<NotificationBean> allNoti,NotiLogListAdapter notiAdapter) {
		this.context=context;
		this.notiList=notiList;
		this.notiAdapter=notiAdapter;
		this.allNoti=allNoti;
	}

	@Override
	public void onClick(View v) {
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(context);
		dialBuilderDel.setTitle("�˸� ��� ����");
		dialBuilderDel.setMessage("��� ����� �����Ͻðڽ��ϱ�?");

		dialBuilderDel.setPositiveButton("Yes",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						NotiLogDatabase db=new NotiLogDatabase(context);
						db.deleteAllLog();
						dialog.dismiss();
						notiList.clear();
						allNoti.clear();
						notiAdapter.notifyDataSetChanged();
					}
				});

		dialBuilderDel.setNegativeButton("No",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				});

		dialBuilderDel.show();
	}

}
