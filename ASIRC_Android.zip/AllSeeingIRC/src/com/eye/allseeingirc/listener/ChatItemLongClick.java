/*
 * << ChatItemLongClick >>
 * - ��ȭ��Ͽ��� ����Ʈ �������� �� Ŭ������ �� �������� �����ϴ� ������
 */

package com.eye.allseeingirc.listener;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.adapter.TalkListAdapter;
import com.eye.allseeingirc.bean.TalkListBean;
import com.eye.allseeingirc.database.MyChannelDatabase;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView.OnItemLongClickListener;

public class ChatItemLongClick implements OnItemLongClickListener {
	Context context;
	TalkListAdapter adapter;
	ArrayList<TalkListBean> list;
	Handler handler;
	
	public ChatItemLongClick(Context context, TalkListAdapter adapter,
			ArrayList<TalkListBean> list,Handler handler) {
		this.context = context;
		this.adapter = adapter;
		this.list = list;
		this.handler=handler;
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			final int position, long id) {
		final String chanName = list.get(position).getChanName();
		AlertDialog.Builder dialBuilderDel = new AlertDialog.Builder(context);
		dialBuilderDel.setTitle(chanName);
		String[] items = { "ä�� �˸� �ѱ�", "�����ϱ�(����)", "��ϻ���" };

		if (list.get(position).getIsAlertable()) {
			items[0] = "ä�� �˸� ����";
		}
		if (list.get(position).getIsSubOn()) {
			items[1] = "������(����)";
			items[2] = "������ ��� ����";
		}

		final MyChannelDatabase db = new MyChannelDatabase(context);
		dialBuilderDel.setItems(items, new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
				case 0://�˸�
					list.get(position).setIsAlertable(
							!list.get(position).getIsAlertable());
					db.setChanAlert(chanName, list.get(position)
							.getIsAlertable());
					adapter.notifyDataSetChanged();
					break;
				case 1://����
					if (list.get(position).getIsSubOn()) {//�������� ���
						AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
								.getApplicationContext();
						if (application.remoteClientNetwork.isSocketConnected) {
							JSONObject jsonObject = new JSONObject();
							try {
								jsonObject.put("message", "/part " + chanName);
								application.remoteClientNetwork
										.sendMessage(jsonObject.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
						list.get(position).setIsSubOn(false);
					} else {
						AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
								.getApplicationContext();
						if (application.remoteClientNetwork.isSocketConnected) {
							JSONObject jsonObject = new JSONObject();
							try {
								jsonObject.put("message", "/join " + chanName);
								application.remoteClientNetwork
										.sendMessage(jsonObject.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
						list.get(position).setIsSubOn(true);
					}
					adapter.notifyDataSetChanged();
					break;
				default://���
					db.deleteChannel(chanName);
					if (list.get(position).getIsSubOn()) {//�������� ���
						AllSeiingIRCApplication application = (AllSeiingIRCApplication) context
								.getApplicationContext();
						if (application.remoteClientNetwork.isSocketConnected) {
							JSONObject jsonObject = new JSONObject();
							try {
								jsonObject.put("message", "/part " + chanName);
								application.remoteClientNetwork
										.sendMessage(jsonObject.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
						list.get(position).setIsSubOn(false);
					}
					
					if(list.get(position).getBadge()>0){
						Message msg=new Message();
						msg.what=0;
						msg.arg1=list.get(position).getBadge();
						handler.sendMessage(msg);
					}
					list.remove(position);
					adapter.notifyDataSetChanged();
					break;
				}
			}
		});
		
		dialBuilderDel.show();

		return true;
	}

}
