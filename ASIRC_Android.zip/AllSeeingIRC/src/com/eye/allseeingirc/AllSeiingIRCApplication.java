package com.eye.allseeingirc;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;

import com.eye.allseeingirc.network.RemoteClientNetwork;

public class AllSeiingIRCApplication extends Application{
	public RemoteClientNetwork remoteClientNetwork;
		
	@Override
	public void onCreate(){
		super.onCreate();
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig){
		super.onConfigurationChanged(newConfig);
	}
	
	@Override
	public void onLowMemory(){
		super.onLowMemory();
	}
	
	@Override
	public void onTerminate(){
		super.onTerminate();
	}
	
	public void setRemoteClient(String ip,Handler handler,String channelName){
		remoteClientNetwork=new RemoteClientNetwork(ip,handler,channelName);
		remoteClientNetwork.isSplash=false;
		remoteClientNetwork.setContext(getApplicationContext());//�����ͺ��̽��� �����ϴ� ���� ����ŷ ť�� ó���� ��� �ʿ���...
		remoteClientNetwork.receiveMessageOn();
		
	}
	public void setRemoteClient(String ip,Handler handler,String channelName,boolean isSplash){
		remoteClientNetwork=new RemoteClientNetwork(ip,handler,channelName);
		remoteClientNetwork.isSplash=isSplash;
		remoteClientNetwork.setContext(getApplicationContext());//�����ͺ��̽��� �����ϴ� ���� ����ŷ ť�� ó���� ��� �ʿ���...
		remoteClientNetwork.receiveMessageOn();
		
	}
	
	public void stopRemoteClient(){
		if(remoteClientNetwork!=null){
			remoteClientNetwork.receiveMessageOff();
		}
	}
	
	public void setNetworkHandler(Handler handler,String channelName){
		if(remoteClientNetwork!=null){
			remoteClientNetwork.handler=handler;
			remoteClientNetwork.channelName=channelName;
		}
	}
}
