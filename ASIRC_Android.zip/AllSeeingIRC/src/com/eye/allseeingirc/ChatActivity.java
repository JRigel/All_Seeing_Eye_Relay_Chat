/*
 * << ChatActivity >>
 * 
 * - ä�ù濡 ���� �� ��Ƽ��Ƽ
 * - ��ȭ �� ������ ����� �� �� �ִ�
 */

package com.eye.allseeingirc;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.DrawerListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.eye.allseeingirc.R.menu;
import com.eye.allseeingirc.adapter.BubbleListAdapter;
import com.eye.allseeingirc.adapter.UserListAdapter;
import com.eye.allseeingirc.adapter.WhoisListAdapter;
import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.bean.WhoisBean;
import com.eye.allseeingirc.database.LogDatabase;
import com.eye.allseeingirc.database.MyChannelDatabase;
import com.eye.allseeingirc.database.MyQueryDatabase;
import com.eye.allseeingirc.listener.InviteButtonClick;
import com.eye.allseeingirc.listener.SendButtonClick;
import com.eye.allseeingirc.network.RemoteClientNetwork;
import com.eye.allseeingirc.utils.MemoryUtils;
import com.eye.allseeingirc.utils.MessageParser;
import com.eye.allseeingirc.view.ViewUtils;

public class ChatActivity extends Activity{

	private AllSeiingIRCApplication application;
	
	SharedPreferences pref;

	private MenuItem search;
	SearchView searchView;
	private ActionBar chatActionBar;
	private String chatName;
	private ListView bubbleList;
	public EditText editMessage;
	private Button btnSend;
	private Button btnMode;
	LinearLayout sendBox;
	public ImageView back;

	//��ξ� ���̾ƿ��κ�
	private DrawerLayout drawerChatInfo;
	private View drawerView;
	public ListView userList;// ������ ����� �޾ƿ��� ����Ʈ
	public ArrayList<String> userArrayList = new ArrayList<String>();
	public UserListAdapter userArrayAdapter;
	public ProgressBar loadingUser;
	public static int mode_o_count;
	public static int mode_v_count;
	public TextView tvOCount;
	public TextView tvVCount;
	public Button btnInvite;

	public ArrayList<BubbleBean> bubbleArrayList = new ArrayList<BubbleBean>();
	public BubbleListAdapter bubbleArrayAdapter;
	LogDatabase logDatabase;

	public boolean isSubOn=false;
	public boolean isDrawerOpen = false;
	private boolean lockListView;
	public boolean commandMode = false;
	public boolean firstDragFlag = true;
	public boolean isSearching=false;
	public boolean isScrollBot=false;

	private Drawable cmdModeOn;
	private Drawable cmdModeOff;
	
	private int backres;

	// ���̾�α׺κ�
	
	public AlertDialog userInfoDial;
	public LayoutInflater userInfoInflater;
	public View userInfoLayout;
	public ListView infoList;
	public ArrayList<WhoisBean> whoisArrayList = new ArrayList<WhoisBean>();
	public WhoisListAdapter whoisArrayAdapter;
	public ProgressBar loadingUserInfo;
	public TextView tvMemCnt;
	
	MyChannelDatabase myChanDB;

	// ���� ����
	public Button btnClose;
	public TextView viewTopic;
	public boolean isOpened;
	
	//���ο� �޽��� ����
	public TextView viewNextMsg;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_chat);
		
		back=(ImageView)findViewById(R.id.chat_background);
		
		pref = getSharedPreferences("pref",
				MODE_PRIVATE);
		if(pref.getBoolean("back", false)){
			backres=pref.getInt("backres",R.drawable.background_5);
			back.setImageResource(backres);
		}else{
			String uri=pref.getString("backuri", "");
			try{
				back.setImageURI(Uri.parse(uri));
			}catch(Throwable e){
				SharedPreferences.Editor editor=pref.edit();
				editor.putBoolean("back", true);
				editor.putInt("backres", R.drawable.background_5);
				editor.commit();
				back.setImageResource(R.drawable.background_5);
			}
		}
		myChanDB=new MyChannelDatabase(this);
		getActionBar().setHomeButtonEnabled(false);

		cmdModeOn = getResources().getDrawable(
				R.drawable.ic_flip_to_back_white_36dp);
		cmdModeOff = getResources().getDrawable(
				R.drawable.ic_flip_to_front_white_36dp);

		editMessage = (EditText) findViewById(R.id.edittext_chat);
		bubbleList = (ListView) findViewById(R.id.listView_bubbles);
		btnSend = (Button) findViewById(R.id.btn_send);
		btnMode = (Button) findViewById(R.id.btn_mode);
		sendBox=(LinearLayout) findViewById(R.id.layout_sendmsg);
		
		editMessage.setOnFocusChangeListener(new OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if(hasFocus){
					bubbleList.smoothScrollToPosition(bubbleArrayList.size()-1);
				}else{
					InputMethodManager imm;
					imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					imm.hideSoftInputFromWindow(
							editMessage.getWindowToken(), 0);
				}
			}
		});

		drawerChatInfo = (DrawerLayout) findViewById(R.id.drawer_layout);
		drawerView = (View) findViewById(R.id.drawer_chatsetting);
		userList = (ListView) findViewById(R.id.listView_people);
		userArrayAdapter = new UserListAdapter(this, userArrayList);
		userList.setAdapter(userArrayAdapter);
		loadingUser = (ProgressBar) findViewById(R.id.loading_userlist);
		tvMemCnt = (TextView) findViewById(R.id.textview_memcnt);
		tvOCount=(TextView)findViewById(R.id.mode_o_count);
		tvVCount=(TextView)findViewById(R.id.mode_v_count);
		btnInvite=(Button)findViewById(R.id.btn_userinvite);
		userList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(!application.remoteClientNetwork.socket.isClosed()){
					String nick = MessageParser.parseNick((String)parent.getAdapter().getItem(position));
					Message whoisMsg = new Message();
					whoisMsg.what = 6;
					whoisMsg.obj = nick;
					handler.sendMessage(whoisMsg);
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/whois " + nick);
						application.remoteClientNetwork.sendMessage(jsonObject
								.toString());

					} catch (JSONException e) {
						e.printStackTrace();
					}
				}else{
					Toast.makeText(ChatActivity.this, "��Ʈ��ũ ���� ���¸� Ȯ�����ּ���.", Toast.LENGTH_SHORT).show();
				}
			}
		});
		

		// ActionBar ����
		chatActionBar = getActionBar();
		
		// Intent �ޱ�
		Intent intent = getIntent();
		chatName = intent.getStringExtra("listItem");
		JSONObject jsonObject = new JSONObject();
		myChanDB.setChanUnreadZero(chatName);
		isSubOn=myChanDB.isSubOn(chatName);
		if(!isSubOn){//�������� �ƴ�
			sendBox.setVisibility(View.GONE);
			((LinearLayout)findViewById(R.id.layout_userlist)).setVisibility(View.GONE);
			chatActionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#757575")));
			
			drawerChatInfo.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
			drawerView.setVisibility(View.GONE);
		}else{
			
			((TextView)findViewById(R.id.textview_alert)).setVisibility(View.GONE);
		}
		
		chatActionBar.setDisplayHomeAsUpEnabled(true);
		chatActionBar.setTitle(chatName);
		
		btnInvite.setOnClickListener(new InviteButtonClick(this, chatName));
		
		btnClose = (Button) findViewById(R.id.btn_close);
		btnClose.setVisibility(View.GONE);
		viewTopic = (TextView) findViewById(R.id.textview_topic);
		viewTopic.setVisibility(View.GONE);
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
					v.setVisibility(View.GONE);
					viewTopic.setVisibility(View.VISIBLE);
					isOpened = false;
			}
		});
		viewTopic.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
					v.setVisibility(View.GONE);
					btnClose.setVisibility(View.VISIBLE);
					isOpened = true;
			}
		});
		
		viewNextMsg=(TextView) findViewById(R.id.textview_prevmsg);
		viewNextMsg.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				bubbleList.setSelection(bubbleArrayList.size()-1);	
				viewNextMsg.setVisibility(View.GONE);
			}
		});

		// drawer layout ����
		drawerChatInfo.setDrawerListener(new DrawerListener() {
			@Override
			public void onDrawerStateChanged(int arg0) {
			}

			@Override
			public void onDrawerSlide(View arg0, float arg1) {
			}

			@Override
			public void onDrawerOpened(View arg0) {
				isDrawerOpen = true;
				mode_o_count=0;
				mode_v_count=0;
				tvMemCnt.setText("");
				if (isSubOn) {
					JSONObject jsonObject = new JSONObject();
					try {
						jsonObject.put("message", "/n_list " + chatName);
					} catch (JSONException e) {
						e.printStackTrace();
					}
					application.remoteClientNetwork.sendMessage(jsonObject
							.toString());
				}
			}

			@Override
			public void onDrawerClosed(View arg0) {
				isDrawerOpen = false;
				userArrayList.clear();
				loadingUser.setVisibility(View.VISIBLE);
			}
		});

		application = (AllSeiingIRCApplication) getApplicationContext();
		application.setNetworkHandler(handler, chatName);

		// �ҷ�����
		try {
			jsonObject.put("message", " /this_topic " + chatName);
			application.remoteClientNetwork.sendMessage(jsonObject.toString());
			
		} catch (JSONException e) {
			e.printStackTrace();
		}

		bubbleArrayAdapter = new BubbleListAdapter(this, handler,
				bubbleArrayList);
		logDatabase = new LogDatabase(this, chatName);
		logDatabase.setBubbleList(bubbleArrayList);
		
		bubbleList.setOnTouchListener(new OnTouchListener() {

			boolean dragFlag=false;
			float startYPosition = 0,endYPosition=0;

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_UP:
//					if (editMessage.isFocused()) {
//						InputMethodManager imm;
//						imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//						imm.hideSoftInputFromWindow(
//								editMessage.getWindowToken(), 0);
//						editMessage.clearFocus();
//					}
					search.collapseActionView();
					
					ChatActivity.this.getCurrentFocus().clearFocus();
					endYPosition=event.getY();
					if((startYPosition < endYPosition) && (endYPosition - startYPosition) > 300&&dragFlag&&lockListView==false) {
	                    addItems();
	                }
					dragFlag=false;
					startYPosition = 0.0f;
		            endYPosition = 0.0f;
		            firstDragFlag=true;
					break;
					
				case MotionEvent.ACTION_MOVE:
					break;
					
				case MotionEvent.ACTION_DOWN:
					if(firstDragFlag&&bubbleList.getFirstVisiblePosition()==0) {
						startYPosition = event.getY(); //ù��° ��ġ�� Y(����)�� ����
						dragFlag = true;
						
						firstDragFlag= false;
					}
					
					break;

				default:
					break;
				}
				return false;
			}
		});

		// ��ũ�� ������ ���
		bubbleList.setOnScrollListener(new OnScrollListener() {
			
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
			}
			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				final int lastItem = firstVisibleItem + visibleItemCount;
		           if(lastItem == bubbleArrayList.size()) {
		        	   if(viewNextMsg.isShown()){
							viewNextMsg.setVisibility(View.GONE);
						}
		        	   if(!isScrollBot){
		        		   isScrollBot=true;
		        	   }
		           }else{
		        	   if(isScrollBot){
		        		   isScrollBot=false;
		        	   }
		           }
				
			}
		});
		bubbleList.setAdapter(bubbleArrayAdapter);

		// ���۹�ư�� ������
		btnSend.setOnClickListener(new SendButtonClick(this, editMessage,
				handler));
		btnMode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (commandMode) {
					btnMode.setBackground(cmdModeOff);
					commandMode = false;
					Toast.makeText(ChatActivity.this, "��ȭ���",
							Toast.LENGTH_SHORT).show();
				} else {
					btnMode.setBackground(cmdModeOn);
					commandMode = true;
					Toast.makeText(ChatActivity.this, "���ɸ��",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		bubbleList.setSelection(bubbleArrayList.size()-1);

	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		myChanDB.setTopic(chatName, isOpened);
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.chat, menu);
		if(!isSubOn){
			MenuItem itemInfo = menu.findItem(R.id.action_chat_info);
			itemInfo.setVisible(false);
		}
		
		search = menu.findItem(R.id.action_search);
		
		searchView = (SearchView) search.getActionView();
		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			int index = bubbleArrayList.size() - 1;

			@Override
			public boolean onQueryTextSubmit(String query) {// �˻� �õ�
				if (bubbleArrayList.size() > 0) {
					if (!lockListView) {
						// if(prevSearch.equals(query)){
						isSearching = true;
						bubbleArrayList.get(index).searchtxt = "";// sapnable
						for (int i = index - 1; i >= 0; i--) {
							if (bubbleArrayList.get(i).getBubble()
									.contains(query)) {
								bubbleArrayList.get(i).searchtxt = query;// sapnable
								bubbleArrayAdapter.notifyDataSetChanged();// sapnable
								bubbleList.smoothScrollToPosition(i);
								bubbleList.setSelection(i);

								index = i;
								i = -1;
								isSearching = false;
							}
						}
						if (isSearching) {
							searchItems(query);
						}
						// }
					}
				}else{
					Toast.makeText(ChatActivity.this, "��ȭ����� �����ϴ�.", Toast.LENGTH_SHORT).show();
				}
				return true;
			}

			@Override
			public boolean onQueryTextChange(String newText) {// �Է����� ��
				if (bubbleArrayList.size() > 0) {
					isSearching = false;
					bubbleArrayList.get(index).searchtxt = "";
					for (int i = bubbleArrayList.size() - 1; i >= 0; i--) {
						if (bubbleArrayList.get(i).getBubble()
								.contains(newText)) {
							bubbleArrayList.get(i).searchtxt = newText;// sapnable
							bubbleArrayAdapter.notifyDataSetChanged();// sapnable
							bubbleList.setSelection(i);
							index = i;
							i = -1;
						}
					}
				}
				return true;
			}
		});
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_chat_info:
			if (isDrawerOpen) {
				drawerChatInfo.closeDrawers();
			} else {
				InputMethodManager imm;
				imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(editMessage.getWindowToken(), 0);
				editMessage.clearFocus();
				drawerChatInfo.openDrawer(drawerView);
			}
			return true;

		case android.R.id.home:// �ڷΰ���
			finish();
			overridePendingTransition(0, 0);
			return true;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onStop() {
		super.onStop();
	}

	private void addItems() {
		lockListView = true;

		Runnable run = new Runnable() {

			@Override
			public void run() {
				int position=logDatabase.updateBubbleList(bubbleArrayList);
				bubbleArrayAdapter.notifyDataSetChanged();
				
				if(position==0){
					Toast.makeText(ChatActivity.this, "�� �̻� ����� �����ϴ�.", Toast.LENGTH_SHORT).show();
				}else{
					bubbleList.setSelection(position);
					bubbleList.smoothScrollToPosition(position-1);
				}

				lockListView = false;
			}
		};

		Handler postHandler = new Handler();
		postHandler.postDelayed(run, 0);

	}
	
	private void searchItems(final String keyword) {
		lockListView = true;

		Runnable run = new Runnable() {

			@Override
			public void run() {
				boolean updateable=logDatabase.searchBubbleList(bubbleArrayList,keyword);
				Message msg=new Message();
				msg.what=7;
				if(!updateable){
					msg.arg1=0;
				}else{
					msg.arg1=1;
				}
				handler.sendMessage(msg);

				lockListView = false;
			}
		};
		AsyncTask.execute(run);

	}

	public Handler handler = new Handler() {

		public void handleMessage(Message message) {
			switch (message.what) {
			case 0:

				if (commandMode) {// ���ɸ����
					if (message.obj.toString().contains("\n")) {
						Toast.makeText(ChatActivity.this, "���ɿ���",
								Toast.LENGTH_SHORT).show();
					} else {
						String split[] = message.obj.toString().split(" ");
						if (split[0].equals("/whois")) {
							Message whoisMsg = new Message();
							whoisMsg.what = 6;
							whoisMsg.obj = split[1];
							handler.sendMessage(whoisMsg);
						}
						JSONObject jsonObject = new JSONObject();
						try {
							jsonObject.put("message", message.obj.toString());
							application.remoteClientNetwork
									.sendMessage(jsonObject.toString());
							long now = System.currentTimeMillis();
							Date date = new Date(now);
							SimpleDateFormat timeFormat = new SimpleDateFormat(
									"yyyy�� MM�� dd�� HH:mm:ss");
							BubbleBean bubbleBean = new BubbleBean(
									timeFormat.format(date),
									message.obj.toString());
							bubbleBean.setMode(6);
							bubbleBean.setNickname(pref.getString("mynick", ""));
							logDatabase.insertLogfromUser(bubbleBean);
							bubbleArrayList.add(bubbleBean);
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				} else {// ��ȭ�����
					String replacedMsg = message.obj.toString().replace("\n",
							" ");
					JSONObject jsonObject = new JSONObject();
					try {

						jsonObject.put("message", "/msg " + chatName + " "
								+ replacedMsg);

						Log.e("messagesend", jsonObject.toString());
						application.remoteClientNetwork.sendMessage(jsonObject
								.toString());
						long now = System.currentTimeMillis();
						Date date = new Date(now);
						SimpleDateFormat timeFormat = new SimpleDateFormat(
								"yyyy�� MM�� dd�� HH:mm:ss");
						BubbleBean bubbleBean = new BubbleBean(
								timeFormat.format(date), replacedMsg);
						bubbleBean.setNickname(pref.getString("mynick", ""));
						logDatabase.insertLogfromUser(bubbleBean);
						bubbleArrayList.add(bubbleBean);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}

				bubbleArrayAdapter.notifyDataSetChanged();
				bubbleList.setSelection(bubbleArrayList.size());
				break;
			case 1:
				Toast.makeText(ChatActivity.this, "receive", Toast.LENGTH_SHORT)
						.show();
				break;
			case 2:
				Toast.makeText(ChatActivity.this, "�޽����� ���� �� �����ϴ�.",
						Toast.LENGTH_SHORT).show();
				
				break;

			case 5:// �޽��� �޾��� ���� �ڵ鷯
				switch (message.arg1) {
				case 7:// �����޽���
					if (userInfoDial != null) {
						userInfoDial.cancel();
					}
					Toast.makeText(ChatActivity.this, message.obj.toString(),
							Toast.LENGTH_SHORT).show();
					break;
				case 8:// �޽�������..�� ������Ʈ
					BubbleBean data = (BubbleBean) message.obj;
					bubbleArrayList.add(data);
					bubbleArrayAdapter.notifyDataSetChanged();
					if (!isScrollBot) {// ����Ʈ�� ������ �������� ������ �ʴ´ٸ� ������ ���� ��ư�� ����.
						if (data.getMode() == 4 || data.getMode() == 1) {
							viewNextMsg.setText("[" + data.getNickName()
									+ "] : " + data.getBubble());
							if (!viewNextMsg.isShown()) {
								viewNextMsg.setVisibility(View.VISIBLE);
							}
						}
					} else {
						bubbleList.setSelection(bubbleArrayList.size() - 1);
					}
					break;
				case 9:
					viewTopic.setText(message.obj.toString());
					isOpened = myChanDB.getTopic(chatName);
					if (!isOpened) {
						btnClose.callOnClick();
					}else{
						viewTopic.callOnClick();
					}
					break;
				case 10:
					String nickList[]=message.obj.toString().split(",");
					for (int i = 0; i < nickList.length; i++) {
						userArrayList.add(nickList[i]);
						MessageParser.countNickMode(nickList[i]);
					}
					loadingUser.setVisibility(View.GONE);
					userArrayAdapter.notifyDataSetChanged();
					tvOCount.setText(mode_o_count+"");
					tvVCount.setText(mode_v_count+"");
					tvMemCnt.setText(message.arg2+"");
					break;
				case 11:
					loadingUserInfo.setVisibility(View.GONE);
					whoisArrayList.addAll((Collection<? extends WhoisBean>) message.obj);
					whoisArrayAdapter.notifyDataSetChanged();
					break;
				default:
					break;
				}
				break;

			case 6:// whois ������ ������ ���� ���̾�α� ���� �κ�
				final String username=message.obj.toString();
				AlertDialog.Builder dialBuilder = new AlertDialog.Builder(ChatActivity.this);
				userInfoInflater = (LayoutInflater) ChatActivity.this
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				userInfoLayout = userInfoInflater.inflate(
						R.layout.dialog_whois, (ViewGroup) ChatActivity.this
								.findViewById(R.id.layout_whois));
				infoList = (ListView) userInfoLayout
						.findViewById(R.id.listView_whois);
				loadingUserInfo = (ProgressBar) userInfoLayout
						.findViewById(R.id.loading_usreinfo);
				whoisArrayAdapter = new WhoisListAdapter(ChatActivity.this,
						whoisArrayList);
				infoList.setAdapter(whoisArrayAdapter);
				dialBuilder.setTitle("����� ����");
				dialBuilder.setView(userInfoLayout);
				dialBuilder.setNegativeButton("�ݱ�", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					}
				});
				dialBuilder.setPositiveButton("�ϴ��� ��ȭ",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								MyQueryDatabase queryDB=new MyQueryDatabase(ChatActivity.this);
								int queryId=queryDB.getQueryId(username);
								Intent queryIntent=new Intent(ChatActivity.this,QueryActivity.class);
								queryIntent.putExtra("queryId", queryId);
								queryIntent.putExtra("listItem", username);
								startActivity(queryIntent);
								finish();
							}
						});
				
				loadingUserInfo.setVisibility(View.VISIBLE);
				whoisArrayList.clear();
				whoisArrayAdapter.notifyDataSetChanged();
				userInfoDial=dialBuilder.create();
				userInfoDial.show();
				whoisArrayList
						.add(new WhoisBean("�г���", username));

				break;
			case 7:
				bubbleArrayAdapter.notifyDataSetChanged();
				if(message.arg1==0){
					Toast.makeText(ChatActivity.this, "�� �̻� �˻� ����� �����ϴ�.", Toast.LENGTH_SHORT).show();
					
				}else{
					bubbleList.setSelection(0);
					bubbleList.smoothScrollToPosition(0);
					
				}
				break;

			default:
				break;
			}
		};
	};
}
