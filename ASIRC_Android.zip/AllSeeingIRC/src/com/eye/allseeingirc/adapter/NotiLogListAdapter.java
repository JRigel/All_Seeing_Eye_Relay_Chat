package com.eye.allseeingirc.adapter;

//0 ȣ�� �Ǵ� Ű����
import java.util.ArrayList;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.NotificationBean;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NotiLogListAdapter extends BaseAdapter{
	ArrayList<NotificationBean> arrayList;
	LayoutInflater layoutInflater;
	
	public NotiLogListAdapter(Context context,ArrayList<NotificationBean> arrayList) {
		this.arrayList=arrayList;
		layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		NotificationBean notiBean=arrayList.get(position);
		if(convertView==null){
			convertView=layoutInflater.inflate(R.layout.custom_noti_item, parent,false);
			holder=new ViewHolder();
			holder.tvMsg=(TextView)convertView.findViewById(R.id.noti_item_msg);
			holder.tvTime=(TextView)convertView.findViewById(R.id.noti_item_time);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder)convertView.getTag();
		}
		holder.tvMsg.setText(arrayList.get(position).getMsg());
		holder.tvTime.setText(arrayList.get(position).getTimestamp());
		if(arrayList.get(position).getIsChecked()){//�̹� �о��� ���
			holder.tvMsg.setTextColor(R.color.gray);//����
			convertView.setBackgroundColor(Color.parseColor("#ffffff"));//���
		}else{
			switch (arrayList.get(position).getType()) {
			case 1://����
				holder.tvMsg.setTextColor(Color.parseColor("#F44336"));//������
				
				break;
				
			case 2://�˸�
				holder.tvMsg.setTextColor(Color.parseColor("#4CAF50"));//�ʷ�
				break;
				
			case 3://�ʴ�
				holder.tvMsg.setTextColor(Color.parseColor("#FF9800"));//���
				break;
				
			case 4://�Ӹ�ȣ��
				holder.tvMsg.setTextColor(Color.parseColor("#3F51B5"));//�Ķ�
				break;
				
			case 5://ȣ�� �Ǵ� ����
				holder.tvMsg.setTextColor(Color.parseColor("#3F51B5"));//�Ķ�
				break;

			default://��ȭ�� ���� 6��
				holder.tvMsg.setTextColor(Color.parseColor("#4CAF50"));//�ʷ�
				break;
			}
			convertView.setBackgroundColor(Color.parseColor("#ededed"));//ȸ��
		}
		
		return convertView;
	}
	
	// Filter Class
		public void filter(int type,ArrayList<NotificationBean> allList) {
			arrayList.clear();
			for (NotificationBean wp : allList) 
			{
				if(!wp.getIsChecked()&&wp.getType()==type){
					arrayList.add(wp);
				}
			}
			notifyDataSetChanged();
		}
	
	private class ViewHolder{
		public TextView tvMsg;
		public TextView tvTime;
	}

}
