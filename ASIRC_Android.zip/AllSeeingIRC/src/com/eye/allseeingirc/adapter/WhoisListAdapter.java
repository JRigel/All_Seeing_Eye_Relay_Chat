package com.eye.allseeingirc.adapter;

import java.util.ArrayList;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.WhoisBean;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class WhoisListAdapter extends BaseAdapter{
	Context context;
	ArrayList<WhoisBean> arrayList;
	LayoutInflater layoutInfalter;
	
	TextView tvKey;
	TextView tvValue;
	
	public WhoisListAdapter(Context context,ArrayList<WhoisBean> arrayList) {
		this.context=context;
		this.arrayList=arrayList;
		
		layoutInfalter=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	
	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView==null){
			convertView=layoutInfalter.inflate(R.layout.custom_info, parent,false);
		}
		
		tvKey=(TextView)convertView.findViewById(R.id.textView_key);
		tvValue=(TextView)convertView.findViewById(R.id.textView_value);
		
		tvKey.setText(arrayList.get(position).getKey());
		tvValue.setText(arrayList.get(position).getValue());
		
		return convertView;
	}

}
