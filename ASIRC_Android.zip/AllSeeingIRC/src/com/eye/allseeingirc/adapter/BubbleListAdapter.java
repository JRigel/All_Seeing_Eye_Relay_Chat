/*
 * << BubbleListAdapter >>
 * - ä��â ��ȭ ����Ʈ�並 ���� Ŀ���Ҿ��
 * - ChatActivity������ ����� ��
 * - mode�� �� �������� ������ : ���� ������ ��, ���� ������ ��, �ȳ��޽���
 * - mode0 : �ȳ��޽���
 * - mode1 : ���� ������ ��
 * - mode2 : ���� ������ ��
 */

package com.eye.allseeingirc.adapter;

import java.util.ArrayList;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.TextAppearanceSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.eye.allseeingirc.AllSeiingIRCApplication;
import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.BubbleBean;
import com.eye.allseeingirc.listener.UserNicknameClick;
import com.eye.allseeingirc.view.TypeHolder;

public class BubbleListAdapter extends BaseAdapter {
	Context context;
	Handler handler;
	LayoutInflater layoutInflater;
	ArrayList<BubbleBean> arrayList = new ArrayList<BubbleBean>();
	String userName;
	AllSeiingIRCApplication application;

	int[] id = { R.layout.custom_bubble_mode0, R.layout.custom_bubble_mode1,
			R.layout.custom_bubble_mode2, R.layout.custom_bubble_mode3 };

	public BubbleListAdapter(Context context, Handler handler,
			ArrayList<BubbleBean> arrayList) {
		this.context = context;
		this.handler = handler;
		layoutInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.arrayList = arrayList;

		application = (AllSeiingIRCApplication) context.getApplicationContext();

		SharedPreferences pref = context.getSharedPreferences("pref",
				context.MODE_PRIVATE);
		userName = pref.getString("mynick", "");

	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public int getItemViewType(int position) {
		int mode = arrayList.get(position).getMode();
		if (mode == 0 || mode == 3 || mode == 5) {// bubble mode0
			return 0;
		} else if (mode == 1 || mode == 4) {// bubble mode1
			return 1;
		} else if (mode == 2) {// bubble mode2
			return 2;
		} else if (mode == 10) {
			return 4;
		} else {// bubble node3

			return 3;
		}
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		BubbleBean data = arrayList.get(position);
		int mode = arrayList.get(position).getMode();
		TypeHolder holder = null;
		if (convertView == null) {
			holder = new TypeHolder();
			switch (getItemViewType(position)) {
			case 0:
				convertView = layoutInflater.inflate(
						R.layout.custom_bubble_mode0, parent, false);
				holder.message = (TextView) convertView
						.findViewById(R.id.bubble_message);
				holder.time = (TextView) convertView
						.findViewById(R.id.bubble_time);
				break;

			case 1:
				convertView = layoutInflater.inflate(
						R.layout.custom_bubble_mode1, parent, false);
				holder.message = (TextView) convertView
						.findViewById(R.id.bubble_message);
				holder.time = (TextView) convertView
						.findViewById(R.id.bubble_time);
				holder.name = (TextView) convertView
						.findViewById(R.id.bubble_name);
				break;
			case 2:
				convertView = layoutInflater.inflate(
						R.layout.custom_bubble_mode2, parent, false);
				holder.message = (TextView) convertView
						.findViewById(R.id.bubble_message);
				holder.time = (TextView) convertView
						.findViewById(R.id.bubble_time);
				holder.name = (TextView) convertView
						.findViewById(R.id.bubble_name);
				break;
			case 3:
				convertView = layoutInflater.inflate(
						R.layout.custom_bubble_mode3, parent, false);
				holder.message = (TextView) convertView
						.findViewById(R.id.bubble_message);
				holder.time = (TextView) convertView
						.findViewById(R.id.bubble_time);
				holder.name = (TextView) convertView
						.findViewById(R.id.bubble_name);
				break;

			default:
				convertView = layoutInflater.inflate(
						R.layout.custom_bubble_mode4, parent, false);
			}
			holder.mode = getItemViewType(position);
			convertView.setTag(holder);

		} else {
			holder = (TypeHolder) convertView.getTag();
			if (holder.mode != getItemViewType(position)) {
				holder = new TypeHolder();
				switch (getItemViewType(position)) {
				case 0:
					convertView = layoutInflater.inflate(
							R.layout.custom_bubble_mode0, parent, false);
					holder.message = (TextView) convertView
							.findViewById(R.id.bubble_message);
					holder.time = (TextView) convertView
							.findViewById(R.id.bubble_time);
					break;

				case 1:
					convertView = layoutInflater.inflate(
							R.layout.custom_bubble_mode1, parent, false);
					holder.message = (TextView) convertView
							.findViewById(R.id.bubble_message);
					holder.time = (TextView) convertView
							.findViewById(R.id.bubble_time);
					holder.name = (TextView) convertView
							.findViewById(R.id.bubble_name);
					break;
				case 2:
					convertView = layoutInflater.inflate(
							R.layout.custom_bubble_mode2, parent, false);
					holder.message = (TextView) convertView
							.findViewById(R.id.bubble_message);
					holder.time = (TextView) convertView
							.findViewById(R.id.bubble_time);
					holder.name = (TextView) convertView
							.findViewById(R.id.bubble_name);
					break;
				case 3:
					convertView = layoutInflater.inflate(
							R.layout.custom_bubble_mode3, parent, false);
					holder.message = (TextView) convertView
							.findViewById(R.id.bubble_message);
					holder.time = (TextView) convertView
							.findViewById(R.id.bubble_time);
					holder.name = (TextView) convertView
							.findViewById(R.id.bubble_name);
					break;

				default:
					convertView = layoutInflater.inflate(
							R.layout.custom_bubble_mode4, parent, false);
				}
				holder.mode = getItemViewType(position);
				convertView.setTag(holder);
			}
		}
		if (mode != 10) {
			holder.time.setText(data.getTime());
			if (mode == 0) {
				holder.message.setTextColor(Color.parseColor("#FFFFFF"));
			} else if (mode == 3) {
				holder.message.setTextColor(Color.parseColor("#58adfb"));
			} else if (mode == 5) {
				holder.message.setTextColor(Color.parseColor("#63ec69"));
			} else if (mode == 1 || mode == 4) {
				holder.name.setText(data.getNickName());
				holder.name.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						JSONObject jsonObject = new JSONObject();
						try {
							String name = (((TextView) v).getText()).toString();
							jsonObject.put("message", "/whois " + name);
							application.remoteClientNetwork
									.sendMessage(jsonObject.toString());
							Message whoisMsg = new Message();
							whoisMsg.what = 6;
							whoisMsg.obj = name;
							handler.sendMessage(whoisMsg);

						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				});
				if (mode == 4) {
					holder.message.setTextColor(Color.parseColor("#ff0000"));
				} else {
					holder.message.setTextColor(Color.parseColor("#000000"));
				}
			} else if (mode == 6 || mode == 2) {
				holder.name.setText(data.getNickName());
				holder.name.setOnClickListener(new UserNicknameClick(context));
			}

			String filter = data.searchtxt;
			String itemValue = data.getBubble();

			if (filter.length() > 0) {
				int startIdx = 0;
				String subString = itemValue;
				Spannable spannable = new SpannableString(itemValue);
				while (true) {
					int subIdx = subString.indexOf(filter);
					int startPos = startIdx + subIdx;
					int endPos = startPos + filter.length();
					if (subIdx != -1) {
						ColorStateList blueColor = new ColorStateList(
								new int[][] { new int[] {} },
								new int[] { Color.BLUE });

						TextAppearanceSpan highlightSpan = new TextAppearanceSpan(
								null, Typeface.BOLD, -1, blueColor, null);
						spannable.setSpan(highlightSpan, startPos, endPos,
								Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
						startIdx = endPos;
						if (endPos < itemValue.length()) {
							subString = itemValue.substring(endPos);
						} else {
							break;
						}
					} else {
						break;
					}
				}
				holder.message.setText(spannable);
			} else
				holder.message.setText(itemValue);

		}
		return convertView;

	}
}
