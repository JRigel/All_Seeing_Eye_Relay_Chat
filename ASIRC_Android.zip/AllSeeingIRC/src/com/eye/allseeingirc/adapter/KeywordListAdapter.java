package com.eye.allseeingirc.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.KeywordBean;

public class KeywordListAdapter extends BaseAdapter{
	LayoutInflater layoutInflater;
	ArrayList<KeywordBean> arrayList;
	boolean[] isCeckedConfrim;
	
	public KeywordListAdapter(Context context,ArrayList<KeywordBean> arrayList) {
		this.arrayList=arrayList;
		layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	
	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if(convertView==null){
			convertView=layoutInflater.inflate(R.layout.custom_keyword_item, parent,false);
			holder=new ViewHolder();
			holder.Keyword=(TextView) convertView.findViewById(R.id.checkbox_keyword);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder) convertView.getTag();
		}
		
		holder.Keyword.setText(arrayList.get(position).keyword);
		
		return convertView;
	}
	
	private static class ViewHolder{
		public TextView Keyword;
	}

}
