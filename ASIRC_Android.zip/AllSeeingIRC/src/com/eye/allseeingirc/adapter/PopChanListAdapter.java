/*
 * << PopChanListAdapter >>
 * - �α� ä�� ����Ʈ�並 ���� Ŀ���Ҿ��
 * - MainActivity������ ����� ��
 */

package com.eye.allseeingirc.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.PopChanBean;

public class PopChanListAdapter extends BaseAdapter{
	Context context;
	LayoutInflater layoutInflater;
	int layout;
	View view;
	ArrayList<PopChanBean> arrayList=new ArrayList<PopChanBean>();
	
	TextView tvIsSubOn,tvChanName,tvSubCount,tvTopic;
	
	public PopChanListAdapter(Context context,int layout,View view,ArrayList<PopChanBean> arrayList){
		this.context=context;
		this.layout=layout;
		layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.view=view;
		this.arrayList=arrayList;
	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		int finalPosition=position;
		if(convertView==null){
			convertView=layoutInflater.inflate(layout, parent,false);
		}
		tvIsSubOn=(TextView)convertView.findViewById(R.id.textview_on);
		tvChanName=(TextView)convertView.findViewById(R.id.textview_channame);
		tvSubCount=(TextView)convertView.findViewById(R.id.textview_subcount);
		tvTopic=(TextView)convertView.findViewById(R.id.textview_topic);
		
		if(arrayList.get(finalPosition).getIsSubOn()){
			tvIsSubOn.setText("���� ��");
		}else{
			tvIsSubOn.setText("");
		}
		
		tvChanName.setText(arrayList.get(finalPosition).getChanName());
		tvSubCount.setText(arrayList.get(finalPosition).getSubCount()+"");
		tvTopic.setText(arrayList.get(finalPosition).getTopic());
			
			
		return convertView;
	}

}
