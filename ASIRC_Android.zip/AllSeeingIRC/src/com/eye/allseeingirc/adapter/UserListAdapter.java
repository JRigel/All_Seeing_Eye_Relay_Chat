package com.eye.allseeingirc.adapter;

import java.util.ArrayList;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.utils.MessageParser;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class UserListAdapter extends BaseAdapter{
	Context context;
	ArrayList<String> arrayList;
	LayoutInflater layoutInflater;
	String userName;
	
	
	public UserListAdapter(Context context,ArrayList<String> arrayList) {
		this.context=context;
		this.arrayList=arrayList;
		layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		SharedPreferences pref = context.getSharedPreferences("pref",
				context.MODE_PRIVATE);
		userName = pref.getString("mynick", "");
	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if(convertView==null){
			convertView=layoutInflater.inflate(R.layout.custom_user_item, parent,false);
			holder=new ViewHolder();
			holder.tvUserName=(TextView)convertView.findViewById(R.id.textview_username);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder)convertView.getTag();
		}
		holder.tvUserName.setText(arrayList.get(position));
		int mode=MessageParser.checkNickMode(arrayList.get(position),userName);
		switch (mode) {
		case 0:
			holder.tvUserName.setTextColor(Color.parseColor("#000000"));
			if(!holder.isNormal){
				holder.tvUserName.setTypeface(null, Typeface.NORMAL);
				holder.isNormal=true;
			}
			
			break;
		case 1:
			holder.tvUserName.setTextColor(Color.parseColor("#3F51B5"));
			if(!holder.isNormal){
				holder.tvUserName.setTypeface(null, Typeface.NORMAL);
				holder.isNormal=true;
			}
			break;
		case 2:
			holder.tvUserName.setTextColor(Color.parseColor("#D84315"));
			if(!holder.isNormal){
				holder.tvUserName.setTypeface(null, Typeface.NORMAL);
				holder.isNormal=true;
			}
			break;
		case 3:
			holder.tvUserName.setTextColor(Color.parseColor("#9C27B0"));
			if(!holder.isNormal){
				holder.tvUserName.setTypeface(null, Typeface.NORMAL);
				holder.isNormal=true;
			}
			break;
		case 4:
			holder.tvUserName.setTextColor(Color.parseColor("#00695C"));
			if(holder.isNormal){
				holder.tvUserName.setTypeface(null, Typeface.NORMAL);
				holder.isNormal=false;
			}
			break;

		default:
			break;
		}
		return convertView;
	}
	
	private static class ViewHolder {
		public TextView tvUserName;
		public boolean isNormal=true;
		
	}

}
