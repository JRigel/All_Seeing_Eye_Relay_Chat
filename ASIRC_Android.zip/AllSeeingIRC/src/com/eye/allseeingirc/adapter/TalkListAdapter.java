/*
 * << TalkListAdapter >>
 * - ��ȭ ����Ʈ�並 ���� Ŀ���Ҿ��
 * - MainActivity������ ����� ��
 */

package com.eye.allseeingirc.adapter;

import java.util.ArrayList;

import com.eye.allseeingirc.R;
import com.eye.allseeingirc.bean.TalkListBean;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TalkListAdapter extends BaseAdapter {
	ArrayList<TalkListBean> arrayList;
	LayoutInflater layoutInflater;

	public TalkListAdapter(Context context, ArrayList<TalkListBean> arrayList) {
		this.arrayList = arrayList;
		layoutInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		TalkListBean chanBean = arrayList.get(position);
		if (convertView == null) {
			convertView = layoutInflater.inflate(R.layout.custom_chan_item,
					parent, false);

			holder=new ViewHolder();
			holder.llChanPeopleCount = (LinearLayout) convertView
					.findViewById(R.id.chan_count);
			holder.tvChanName = (TextView) convertView
					.findViewById(R.id.textview_chan_name);
			holder.tvChanPeopleCount = (TextView) convertView
					.findViewById(R.id.textview_chan_people_cnt);
			holder.ivIsAlertable = (ImageView) convertView
					.findViewById(R.id.img_isAlertable);
			holder.tvChanLatestTime = (TextView) convertView
					.findViewById(R.id.textview_chan_latest_time);
			holder.tvBadge = (TextView) convertView
					.findViewById(R.id.chan_badge);
			holder.tvChanLatestMsg = (TextView) convertView
					.findViewById(R.id.chan_latest_msg);
			convertView.setTag(holder);
		}else{
			holder=(ViewHolder) convertView.getTag();
		}

		holder.tvChanName.setText(chanBean.getChanName());
		if (chanBean.getIsAlertable()) {
			holder.ivIsAlertable.setVisibility(View.GONE);
		} else {
			holder.ivIsAlertable.setVisibility(View.VISIBLE);
		}
			
		holder.tvChanLatestTime.setText(chanBean.getLatestTime());
		if (chanBean.getCount() > 0) {
			holder.llChanPeopleCount.setVisibility(View.VISIBLE);
			holder.tvChanPeopleCount.setText(chanBean.getCount() + "");
		} else {
			holder.llChanPeopleCount.setVisibility(View.GONE);
		}
		if (chanBean.getBadge() > 0) {
			if (chanBean.getBadge() > 300) {
				holder.tvBadge.setText("300+");

			} else {
				holder.tvBadge.setText(chanBean.getBadge() + "");
			}
			holder.tvBadge.setVisibility(View.VISIBLE);
		} else {
			holder.tvBadge.setVisibility(View.GONE);
		}
		holder.tvChanLatestMsg.setText(chanBean.getLatestMsg());

		if (!chanBean.getIsSubOn()) {// �������� �ƴ� �� ������
			holder.llChanPeopleCount.setVisibility(View.GONE);
			holder.tvChanName.setTextColor(R.color.not_chan_name);
			convertView.setBackgroundColor(Color.parseColor("#ededed"));
		}else{
			holder.llChanPeopleCount.setVisibility(View.VISIBLE);
			holder.tvChanName.setTextColor(Color.parseColor("#2d3e50"));
			convertView.setBackgroundColor(Color.parseColor("#ffffff"));
		}

		return convertView;
	}

	private static class ViewHolder {
		public int position;
		public LinearLayout llChanPeopleCount;
		public TextView tvChanName;
		public TextView tvChanPeopleCount;
		public ImageView ivIsAlertable;
		public TextView tvChanLatestTime;
		public TextView tvBadge;
		public TextView tvChanLatestMsg;
	}

}
